/*
 * SERIES Virtual Database
 * ========================
 * University of Oxford
 * (c) Ignacio Lamata Martinez, 2011  ignacio.lamata@eng.ox.ac.uk
 * 
 * AlternativeSeriesConnector.java
 * Creation date: 12/07/2011 by ilm
 * Last modification: 12/07/2011 by ilm
 *                    XX/XX/XXXX by XXXXXX  (to be modified by other authors)
 * ------------------------------------------------------------------
 * Schematic class to be completed by a new repository accessor.
 * In this way, should someone need to include their own database, the
 * modification of this source code is the only requirement.
 * 
 * This code can be enabled with  "ALT" as serviceMode in the context.xml.
 * 
 * The resorce name for the database is "seriesAlt" but it can be changed.
 * 
 * 
 */
package uk.ac.ox.eng.ilm.thirdpart;

// Database access imports
import uk.ac.ox.eng.ilm.seriescontainer.*;
import java.sql.Connection;

// Utility class
import uk.ac.ox.eng.ilm.utils.SeriesUtils;
import uk.ac.ox.eng.ilm.utils.SeriesPrivacy;

import java.util.List;


/**
 *
 * @author ilm
 */
public class AlternativeSeriesConnector implements SeriesConnector {



    public AlternativeSeriesConnector() {
    }

    /** 
     * getDataName(): Obtain the name of the database
     * 
     * INPUT: -
     * 
     * OUTPUT:
     * Resource name of the database in the environment of context.xml.
     * 
     * NOTES:
     * -
     *
     */
    /*public String getDataName() {

       return "seriesAlt";

    }*/

    /** 
     * connect():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */

    public boolean connect() throws Exception {

        return false;

    }
    /** 
     * disconnect():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */

    public boolean disconnect(){

        return false;

    }

    /** 
     * verifyKRConnection():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */

    public boolean verifyKRConnection() throws Exception {

        return false;

    }

    /** 
     * startService():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    
    public int startService(String opName, String source, StringBuilder last_id){

        return 0;

    }
    /** 
     * endServiceOK():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */

    public int endServiceOK(StringBuilder last_id){

        return 0;

    }

    /** 
     * getVersionInformation():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public String getVersionInformation() throws Exception {

        return null;

    }

    /** 
     * getTestInformation():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<String> getTestInformation() throws Exception {

        return null;

    }
    
    /** 
     * getListProjectIDs():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<String> getListProjectIDs() throws Exception {

        return null;

    }

    /** 
     * getListClosedProjectIDs():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<String> getListClosedProjectIDs() throws Exception {

        return null;

    }

    /** 
     * getListProjectIDs():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<String> getListProjectIDs(int iPrivacy) throws Exception {

        return null;

    }

    /** 
     * getProjectbyID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public Project getProjectbyID(String idProject) throws Exception {

        return null;

    }

    /** 
     * getSpecimenbyID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public Specimen getSpecimenbyID(String idSpecimen) throws Exception {

       return null;

    }

    /** 
     * getStructuralComponentsbySpecimenID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<StructuralComponent> getStructuralComponentsbySpecimenID(String idSpecimen) throws Exception {

        return null;

    }

     /** 
     * getExperimentbyID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public Experiment getExperimentbyID(String idExperiment) throws Exception {

        return null;

    }

    /** 
     * getComputationbyID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public Computation getComputationbyID(String idComputation) throws Exception {

        return null;

    }

    /** 
     * getDetLoadCharbyExperimentComputationID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<DetLoadChar> getDetLoadCharbyExperimentComputationID(String idExperimentComputation) throws Exception {

        return null;

    }

     /** 
     * getProjectDocumentsbyProjectID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Document> getProjectDocumentsbyProjectID(String idProject) throws Exception {

        return null;

    }

     /** 
     * getSpecimenDocumentsbySpecimenID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Document> getSpecimenDocumentsbySpecimenID(String idSpecimen) throws Exception {

        return null;

    }

     /** 
     * getSpecimenImagesbySpecimenID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Image> getSpecimenImagesbySpecimenID(String idSpecimen) throws Exception {

        return null;

    }

     /** 
     * getExperimentDocumentsbyExperimentID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Document> getExperimentDocumentsbyExperimentID(String idExperiment) throws Exception {

        return null;

    }

    /** 
     * getComputationDocumentsbyComputationID():
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Document> getComputationDocumentsbyComputationID(String idComputation) throws Exception {

        return null;

    }

     /** 
     * getExperimentImagesbyExperimentID:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Image> getExperimentImagesbyExperimentID(String idExperiment) throws Exception {

        return null;

    }

     /** 
     * getComputationImagesbyComputationID:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Image> getComputationImagesbyComputationID(String idComputation) throws Exception {

        return null;

    }

 
     /** 
     * getExperimentVideosbyExperimentID:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Video> getExperimentVideosbyExperimentID(String idExperiment) throws Exception {

        return null;

    }

     /** 
     * getComputationVideosbyComputationID:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public List<Video> getComputationVideosbyComputationID(String idComputation) throws Exception {

        return null;

    }

    /** 
     * getDownloadablebyID:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public Downloadable getDownloadablebyID(String sPartnership, String sDownloadRoot, String sObjectCategory, String sObjectId) throws Exception {

        return null;

    }
    
    /** 
     * projectIsShareable:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public boolean projectIsShareable(String idProject) throws Exception {

        return false;

    }

    /** 
     * specimenIsShareable:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public boolean specimenIsShareable(String idSpecimen) throws Exception {

        return false;

    }
    /** 
     * experimentIsShareable:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public boolean experimentIsShareable(String idExp) throws Exception {

        return false;

    }
    /** 
     * computationIsShareable:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public boolean computationIsShareable(String idComp) throws Exception {

        return false;

    }
    /** 
     * signalIsShareable:
     * -
     * 
     * INPUT:
     * -
     * 
     * OUTPUT:
     * -
     * 
     * NOTES:
     * -
     *
     */
    public boolean signalIsShareable(String idSignal) throws Exception {

        return false;

    }
}