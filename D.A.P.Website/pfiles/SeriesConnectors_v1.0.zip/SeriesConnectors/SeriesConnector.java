/*
 * SERIES Virtual Database
 * ========================
 * University of Oxford
 * (c) Ignacio Lamata Martinez, 2011  ignacio.lamata@eng.ox.ac.uk
 * 
 * SeriesConnector.java
 * Creation date: 10/02/2011 by ilm
 * Last modification: 21/09/2011 by ilm  (no Connection object)
 *                    11/07/2011 by ilm
 * ------------------------------------------------------------------
 * This interface defines the basic methods that will be called by the Web Service.
 * 
 * Any class acting as a translator between the local database and the
 * Oxford Web Service should implement this interface.
 * 
 * 
 * ADDITIONAL NOTE FOR THE METHODS RETURNING IDs (getListProjectIDs) :
 * The University of Oxford SERIES Database uses UNSIGNED INTEGER values for
 * ID columns. This provides a storage range from 0 to 4.294.967.295. This value
 * should be hold on a Java type java.lang.Long / long. However, the Java type
 * java.lang.Integer / int is used in most of the cases, which allows a range of
 * -2.147.483.648 to 2.147.483.648. It is not expected that the database will store
 * more than 2.147.483.648 elements on the same table (projects, specimens, etc) so
 * the int value will work faster, taking less space. After a testing stage, some
 * exceptions can be considered in the case of Signals, Documents or Images.
 * PLEASE BE AWARE that in the extremely unlikely situation of having more than
 * 2.147.483.648 elements stored on a single table (whether they are PUBLIC or not),
 * the Web Service will NOT manage it properly.
 * 
 */

package uk.ac.ox.eng.ilm.seriescontainer;

import java.util.List;
import java.io.InputStream;

/**
 *
 * @author ilm
 */
public interface SeriesConnector {

    // Connect and disconnect to the KR
    public boolean connect() throws Exception;
    public boolean disconnect();
    public boolean verifyKRConnection() throws Exception;

    // Record when a service is called. Service data structures can be initialised.
    int startService(String opName, String source, StringBuilder last_id);
    int endServiceOK(StringBuilder last_id);

    // Obtain information of the name of the database (for the resource name in the environment of context)
    //String getDataName();

    // Obtain information of the database version
    String getVersionInformation() throws Exception;

    // Obtain some information from the database for testing purposes
    List<String> getTestInformation() throws Exception;

    // Obtain all "shareable" or "public" project IDs
    List<String> getListProjectIDs() throws Exception;

    // Obtain all "shareable" or "public" project IDs that are closed. This is actually an optional method, it could return an empty list.
    List<String> getListClosedProjectIDs() throws Exception;    

    // Obtain all project IDs of a specific privacy (ex. PARTNER, PUBLIC, etc)
    List<String> getListProjectIDs(int iPrivacy) throws Exception;

    // Obtain Project Level information
    Project getProjectbyID(String idProject) throws Exception;

    // Obtain Specimen Level information
    Specimen getSpecimenbyID(String idSpecimen) throws Exception;

    // Obtain Structural Component information
    List<StructuralComponent> getStructuralComponentsbySpecimenID(String idSpecimen) throws Exception;

    // Obtain Experiment / Computation information
    Experiment getExperimentbyID(String idExperiment) throws Exception;
    Computation getComputationbyID(String idComputation) throws Exception;
    List<DetLoadChar> getDetLoadCharbyExperimentComputationID(String idExperimentComputation) throws Exception;

    // Obtain Documents/Images/Videos of the different Levels
    List<Document> getProjectDocumentsbyProjectID(String idProject) throws Exception;
    List<Document> getSpecimenDocumentsbySpecimenID(String idSpecimen) throws Exception;
    List<Image> getSpecimenImagesbySpecimenID(String idSpecimen) throws Exception;
    List<Document> getExperimentDocumentsbyExperimentID(String idExperiment) throws Exception;
    List<Image> getExperimentImagesbyExperimentID(String idExperiment) throws Exception;
    List<Video> getExperimentVideosbyExperimentID(String idExperiment) throws Exception;
    List<Document> getComputationDocumentsbyComputationID(String idComputation) throws Exception;
    List<Image> getComputationImagesbyComputationID(String idComputation) throws Exception;
    List<Video> getComputationVideosbyComputationID(String idComputation) throws Exception;

    // Obtain a file (normally document, images, videos or signals)
    Downloadable getDownloadablebyID(String sPartnership, String sDownloadRoot, String sObjectCategory, String sObjectId) throws Exception;

    // Deal with PRIVACY of elements
    public boolean projectIsShareable(String idProject) throws Exception;
    public boolean specimenIsShareable(String idSpecimen) throws Exception;
    public boolean experimentIsShareable(String idExp) throws Exception;
    public boolean computationIsShareable(String idComp) throws Exception;
    public boolean signalIsShareable(String idSignal) throws Exception;

}
