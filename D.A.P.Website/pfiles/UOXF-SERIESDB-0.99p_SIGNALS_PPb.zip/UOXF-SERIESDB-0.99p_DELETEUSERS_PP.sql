DROP USER `userWS`;
DROP USER `userINT`;
DROP USER `userCache`;