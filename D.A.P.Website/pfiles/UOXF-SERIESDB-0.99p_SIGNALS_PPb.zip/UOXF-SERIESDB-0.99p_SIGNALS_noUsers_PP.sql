SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

DROP SCHEMA IF EXISTS `seriesdb` ;
CREATE SCHEMA IF NOT EXISTS `seriesdb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;

-- -----------------------------------------------------
-- Table `seriesdb`.`ProjectMainFocus`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ProjectMainFocus` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ProjectMainFocus` (
  `idProjectMainFocus` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `projectMainFocus` VARCHAR(100) NOT NULL ,
  PRIMARY KEY (`idProjectMainFocus`) ,
  UNIQUE INDEX `uniqueKeys` (`projectMainFocus` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Project`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Project` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Project` (
  `idProject` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID of the Project' ,
  `projectTitle` VARCHAR(130) NOT NULL COMMENT 'Official title of the Project. Ex: Seismic Engineering Research Infrastructures for European Synergies' ,
  `acronym` VARCHAR(15) NULL DEFAULT NULL COMMENT 'Acronim or common name of the Project. Ex: SERIES, UKNEES...' ,
  `projectStartDate` TIMESTAMP NULL COMMENT 'Date when the project starts officially.' ,
  `projectEndDate` TIMESTAMP NULL COMMENT 'Date when the project is finished.' ,
  `projectDescription` TEXT NULL DEFAULT NULL COMMENT 'Brief description of the Project. This can be the project\'s official description.' ,
  `projectCreationDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Project creation date in the Database. It should hold the date that the project was added in the Database.' ,
  `projectStatus` ENUM('NEW','FORESEEN','IN PROGRESS','FINISHED') NOT NULL DEFAULT 'NEW' ,
  `fundingOrganization` VARCHAR(100) NULL COMMENT 'Organization funding the project' ,
  `projectMainFocus` INT UNSIGNED NOT NULL ,
  `projectUpdate` ENUM('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN' ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  `creator_idUser` INT UNSIGNED NOT NULL COMMENT 'ID of the user who added the Project into the Database.' ,
  `lastModification_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_time` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  PRIMARY KEY (`idProject`) ,
  UNIQUE INDEX `UniqueKeys` (`idProject` ASC, `projectTitle` ASC) ,
  INDEX `fk_Project_ProjectMainFocus1` (`projectMainFocus` ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  INDEX `projectUpdate` (`projectUpdate` ASC) ,
  CONSTRAINT `fk_Project_ProjectMainFocus1`
    FOREIGN KEY (`projectMainFocus` )
    REFERENCES `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Institution`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Institution` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Institution` (
  `idInstitution` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `institutionName` VARCHAR(100) NOT NULL COMMENT 'Formal name of the institution. Ex: University of Oxford' ,
  `institutionAcronym` VARCHAR(15) NULL DEFAULT NULL COMMENT 'Acronim or short name for the institution. Ex: UOXF' ,
  `institutionContact` VARCHAR(20) NULL DEFAULT NULL COMMENT 'Contact Details, such as a generic phone number.' ,
  `location` VARCHAR(30) NULL DEFAULT NULL ,
  `institutionWebsite` VARCHAR(255) NULL DEFAULT NULL ,
  PRIMARY KEY (`idInstitution`) ,
  UNIQUE INDEX `UniqueKeys` (`idInstitution` ASC, `institutionName` ASC, `institutionAcronym` ASC) ,
  UNIQUE INDEX `institutionName_UNIQUE` (`institutionName` ASC) ,
  UNIQUE INDEX `institutionAcronym_UNIQUE` (`institutionAcronym` ASC) )
ENGINE = InnoDB
COMMENT = 'List with all the participants institutions available';


-- -----------------------------------------------------
-- Table `seriesdb`.`Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Image` (
  `idImage` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `imageName` VARCHAR(50) NOT NULL COMMENT 'Name for the image' ,
  `imageDate` TIMESTAMP NULL COMMENT 'Date when the image was taken.' ,
  `imageFormat` ENUM('JPG','BMP','TIFF','PNG','GIF','ZIP','RAR','WEB','OTH') NOT NULL ,
  `imageLocation` ENUM('INTERNAL','EXTERNAL','ENCLOSED') NOT NULL DEFAULT 'INTERNAL' COMMENT 'INTERNAL:image in local site (EX:/series/img.jpg or  http://www.ox.ac.uk/series/img.jpg)\nEXTERNAL:image in external site,access protocol (http://, ftp://, etc) must be specified.\nENCLOSED:image embedded in the db,col:\"enclosedImage\".' ,
  `imageAuthor` VARCHAR(100) NULL COMMENT 'Author or copyright owner (person, company...) of the image' ,
  `imageURI` VARCHAR(255) NULL COMMENT 'Image location (Uniform Resource Identifier). It can be in the local machine or in a remote one.' ,
  `enclosedImage` LONGBLOB NULL COMMENT 'Optional to store the image in the DB' ,
  `imageSize` DOUBLE UNSIGNED NOT NULL COMMENT 'Image size in KB (should admit not only whole numbers).' ,
  `summary` TINYTEXT NULL COMMENT 'Brief description of the image.' ,
  `hashValue` TINYBLOB NOT NULL COMMENT 'File CRC to avoid duplicates.' ,
  `downloadAllowed` ENUM('YES','NO') NOT NULL DEFAULT 'YES' ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  PRIMARY KEY (`idImage`) ,
  UNIQUE INDEX `uniqueKeys` (`idImage` ASC) ,
  UNIQUE INDEX `hashValue_UNIQUE` (`hashValue`(20) ASC) ,
  INDEX `hashValue_INDEX` (`hashValue`(20) ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  INDEX `download_INDEX` (`downloadAllowed` ASC) )
ENGINE = InnoDB
COMMENT = 'Graphic image or photo.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Person` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Person` (
  `idPerson` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID of the Person' ,
  `foreName` VARCHAR(25) NOT NULL COMMENT 'Name of the person. Ex: Ignacio' ,
  `familyName` VARCHAR(80) NOT NULL COMMENT 'Surname of the person. Ex: Lamata Martinez' ,
  `contactEmail` VARCHAR(70) NOT NULL COMMENT 'Contact E-mail. Ex: ignacio.lamata@eng.ox.ac.uk' ,
  `contactPhone` VARCHAR(20) NULL DEFAULT NULL COMMENT 'Usual work contact phone (landline or mobile).' ,
  `userImage` INT UNSIGNED NULL ,
  `institutionID` INT UNSIGNED NOT NULL COMMENT 'Institution ID of the Person.\nInstitution in which the person works for.' ,
  `idUser` INT UNSIGNED NULL DEFAULT NULL COMMENT 'User ID for existing user interface tables (ex. UKNEES Website).' ,
  `userID` INT UNSIGNED NULL COMMENT 'User ID for the interface.' ,
  PRIMARY KEY (`idPerson`) ,
  INDEX `fk_Person_Institution1` (`institutionID` ASC) ,
  UNIQUE INDEX `UniqueKeys` (`idPerson` ASC, `contactEmail` ASC, `idUser` ASC, `userID` ASC) ,
  INDEX `idUser_INDEX` (`idUser` ASC) ,
  INDEX `fk_Person_Image1` (`userImage` ASC) ,
  CONSTRAINT `fk_Person_Institution1`
    FOREIGN KEY (`institutionID` )
    REFERENCES `seriesdb`.`Institution` (`idInstitution` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Person_Image1`
    FOREIGN KEY (`userImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Human resources working in a Project.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Document` (
  `idDocument` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `documentTitle` VARCHAR(150) NOT NULL COMMENT 'Main title of the document.' ,
  `documentAuthor` VARCHAR(300) NOT NULL COMMENT 'Author or authors of the document' ,
  `documentCreationDate` TIMESTAMP NOT NULL COMMENT 'Creation date of the document.' ,
  `documentFormat` ENUM('DOC','PDF','TXT','ZIP','RAR','WEB','OTH') NOT NULL COMMENT 'Format of the document: DOC, PDF, TXT, WEB (unknown-URL link), OTHER (other file or unknown)...' ,
  `documentSize` DOUBLE UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Document size in KB (should admit not only whole numbers --from bytes to KB the size could be 1.34, for example).' ,
  `abstract` TEXT NOT NULL COMMENT 'Abstract or summary of the document.' ,
  `scope` VARCHAR(150) NOT NULL DEFAULT 'Project document' COMMENT 'If the document was used for a Journal or Conference, this field defines the name of the Journal/Conference.\n\nOtherwise it has the default value \'Project document\'' ,
  `documentLocation` ENUM('INTERNAL','EXTERNAL','ENCLOSED') NOT NULL DEFAULT 'INTERNAL' COMMENT 'INTERNAL:doc in local site (EX:/series/mydocument.pdf or  http://www.ox.ac.uk/series/mydocument.pdf)\nEXTERNAL:doc in external site,access protocol (http://, ftp://, etc) must be specified.\nENCLOSED:doc embedded in the db,col:\"enclosedDocument\".' ,
  `documentURI` VARCHAR(255) NULL COMMENT 'Document location (Uniform Resource Identifier).RELATIVE or ABSOLUTE URI.Must be enough for the system to know where (and how) to access the document.\nIf the document is enclosed in the DB, this field can be set to \"seriesdb://\".' ,
  `originalDocumentURI` VARCHAR(255) NULL COMMENT 'Original document location (Uniform Resource Identifier). It can be in the local machine or in a remote one.' ,
  `enclosedDocument` LONGBLOB NULL COMMENT 'Optional, to store the document within the DB' ,
  `enclosedOriginalDocument` LONGBLOB NULL COMMENT 'Optional, to store the original document within the DB' ,
  `downloadTimes` INT UNSIGNED NULL DEFAULT 0 COMMENT 'This field can be used for statistics or to restrict downloads.' ,
  `hashValue` TINYBLOB NOT NULL COMMENT 'File CRC to avoid duplicates.' ,
  `downloadAllowed` ENUM('YES','NO') NOT NULL DEFAULT 'YES' COMMENT 'This field can be used to restrict downloads' ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  `creator_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_time` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  PRIMARY KEY (`idDocument`) ,
  UNIQUE INDEX `uniqueKeys` (`idDocument` ASC) ,
  UNIQUE INDEX `hash_UNIQUE` (`hashValue`(20) ASC) ,
  INDEX `hash_INDEX` (`hashValue`(20) ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  INDEX `download_INDEX` (`downloadAllowed` ASC) )
ENGINE = InnoDB
COMMENT = 'Generic document or file.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Project_Person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Project_Person` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Project_Person` (
  `Project_idProject` INT UNSIGNED NOT NULL ,
  `Person_idPerson` INT UNSIGNED NOT NULL ,
  `role` ENUM('PRINCIPAL INVESTIGATOR','LOCAL COINVESTIGATOR','OTHER') NOT NULL COMMENT '- Principal Investigator: People in highest level in charge of the project. Principal investigator at site infrastructure.\n- Local CoInvestigator\n- Test Agent' ,
  PRIMARY KEY (`Project_idProject`, `Person_idPerson`, `role`) ,
  INDEX `fk_Project_has_Person_Project` (`Project_idProject` ASC) ,
  INDEX `fk_Project_has_Person_Person1` (`Person_idPerson` ASC) ,
  CONSTRAINT `fk_Project_has_Person_Project`
    FOREIGN KEY (`Project_idProject` )
    REFERENCES `seriesdb`.`Project` (`idProject` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_has_Person_Person1`
    FOREIGN KEY (`Person_idPerson` )
    REFERENCES `seriesdb`.`Person` (`idPerson` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Relationship between Projects and Persons';


-- -----------------------------------------------------
-- Table `seriesdb`.`Infrastructure`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Infrastructure` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Infrastructure` (
  `idInfrastructure` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Infrastructure ID.' ,
  `infrastructureName` VARCHAR(40) NOT NULL COMMENT 'Name and location of the infastructure. Ex: CEA SACLAY, ELSA ISPRA...' ,
  `facilityName` VARCHAR(40) NOT NULL COMMENT 'Name of the resource used within the infrastructure. Ex: AZALEE, CABLE FACILITY, COMPUTER...' ,
  `location` VARCHAR(20) NOT NULL ,
  `InfrastructureImage` INT UNSIGNED NULL ,
  PRIMARY KEY (`idInfrastructure`) ,
  UNIQUE INDEX `UniqueKeys` (`idInfrastructure` ASC) ,
  INDEX `fk_Infrastructure_Image1` (`InfrastructureImage` ASC) ,
  CONSTRAINT `fk_Infrastructure_Image1`
    FOREIGN KEY (`InfrastructureImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Location and name of the resources used in the project.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Project_Infrastructure`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Project_Infrastructure` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Project_Infrastructure` (
  `Project_idProject` INT UNSIGNED NOT NULL ,
  `Infrastructure_idInfrastructure` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`Project_idProject`, `Infrastructure_idInfrastructure`) ,
  INDEX `fk_Project_has_Infrastructure_Project1` (`Project_idProject` ASC) ,
  INDEX `fk_Project_has_Infrastructure_Infrastructure1` (`Infrastructure_idInfrastructure` ASC) ,
  CONSTRAINT `fk_Project_has_Infrastructure_Project1`
    FOREIGN KEY (`Project_idProject` )
    REFERENCES `seriesdb`.`Project` (`idProject` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_has_Infrastructure_Infrastructure1`
    FOREIGN KEY (`Infrastructure_idInfrastructure` )
    REFERENCES `seriesdb`.`Infrastructure` (`idInfrastructure` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Main infrastructures and facilities used for the project.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Specimen`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Specimen` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Specimen` (
  `idSpecimen` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `specimenName` VARCHAR(45) NOT NULL ,
  `projectID` INT UNSIGNED NOT NULL COMMENT 'Project ID that holds the Specimen.' ,
  `max_Length` DOUBLE UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Value in meters. \"0\" means unknown or N/A' ,
  `max_Width` DOUBLE UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Value in meters. \"0\" means unknown or N/A' ,
  `max_Height` DOUBLE UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Value in meters. \"0\" means unknown or N/A' ,
  `max_Depth` DOUBLE NOT NULL DEFAULT 0 COMMENT 'Value in meters. \"0\" means unknown or N/A' ,
  `specimenMass` DOUBLE UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Value in Kgr. \"0\" means unknown or N/A' ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  `creator_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_time` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  PRIMARY KEY (`idSpecimen`) ,
  UNIQUE INDEX `uniqueKeys` (`idSpecimen` ASC) ,
  INDEX `fk_Specimen_Project1` (`projectID` ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  CONSTRAINT `fk_Specimen_Project1`
    FOREIGN KEY (`projectID` )
    REFERENCES `seriesdb`.`Project` (`idProject` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Specimens tested in a project.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Project_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Project_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Project_Document` (
  `Project_idProject` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  `documentType` ENUM('PRELIMINARY','ONGOING','FINAL','JOURNAL','CONFERENCE') NOT NULL ,
  PRIMARY KEY (`Project_idProject`, `Document_idDocument`, `documentType`) ,
  INDEX `fk_Project_has_Document_Project1` (`Project_idProject` ASC) ,
  INDEX `fk_Project_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_Project_has_Document_Project1`
    FOREIGN KEY (`Project_idProject` )
    REFERENCES `seriesdb`.`Project` (`idProject` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Reports in a Project.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Specimen_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Specimen_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Specimen_Document` (
  `Specimen_idSpecimen` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  `documentType` ENUM('COORDREFSYSTEM','SCALING','GEOMETRY','CONSTRUCTION','TRANSPORT','DEMOLITION','PRELIMINARY','ONGOING','FINAL') NOT NULL ,
  PRIMARY KEY (`Specimen_idSpecimen`, `Document_idDocument`, `documentType`) ,
  INDEX `fk_Specimen_has_Document_Specimen1` (`Specimen_idSpecimen` ASC) ,
  INDEX `fk_Specimen_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_Specimen_has_Document_Specimen1`
    FOREIGN KEY (`Specimen_idSpecimen` )
    REFERENCES `seriesdb`.`Specimen` (`idSpecimen` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Specimen_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Documents for a Specimen.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Specimen_Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Specimen_Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Specimen_Image` (
  `Specimen_idSpecimen` INT UNSIGNED NOT NULL ,
  `Image_idImage` INT UNSIGNED NOT NULL ,
  `imageType` ENUM('CONSTRUCTION','TRANSPORT','DEMOLITION','MAIN') NOT NULL ,
  PRIMARY KEY (`Specimen_idSpecimen`, `Image_idImage`, `imageType`) ,
  INDEX `fk_Specimen_has_Image_Specimen1` (`Specimen_idSpecimen` ASC) ,
  INDEX `fk_Specimen_has_Image_Image1` (`Image_idImage` ASC) ,
  CONSTRAINT `fk_Specimen_has_Image_Specimen1`
    FOREIGN KEY (`Specimen_idSpecimen` )
    REFERENCES `seriesdb`.`Specimen` (`idSpecimen` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Specimen_has_Image_Image1`
    FOREIGN KEY (`Image_idImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Images for a Specimen.';


-- -----------------------------------------------------
-- Table `seriesdb`.`StructuralComponentType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`StructuralComponentType` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`StructuralComponentType` (
  `idStructuralComponentType` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `typeName` VARCHAR(90) NOT NULL COMMENT 'Ex: 2D frame,tunnels,reinforced soil, etc' ,
  PRIMARY KEY (`idStructuralComponentType`) ,
  UNIQUE INDEX `uniqueKeys` (`typeName` ASC) )
ENGINE = InnoDB
COMMENT = 'Structural Systems or Elements (just names)';


-- -----------------------------------------------------
-- Table `seriesdb`.`StructuralComponent`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`StructuralComponent` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`StructuralComponent` (
  `idStructuralComponent` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `structuralComponentName` VARCHAR(70) NOT NULL COMMENT 'Custom name' ,
  `specimenID` INT UNSIGNED NOT NULL ,
  `SCtypeID` INT UNSIGNED NOT NULL COMMENT 'Name (type) of the Structural Element. Ex: 2D frame,tunnels,reinforced soil, etc' ,
  `materialDescription` VARCHAR(100) NULL ,
  PRIMARY KEY (`idStructuralComponent`) ,
  UNIQUE INDEX `uniqueKeys` (`idStructuralComponent` ASC) ,
  INDEX `fk_StructuralComponent_Specimen1` (`specimenID` ASC) ,
  INDEX `fk_StructuralComponent_StructuralComponentType1` (`SCtypeID` ASC) ,
  UNIQUE INDEX `structuralComponentName_UNIQUE` (`structuralComponentName` ASC) ,
  CONSTRAINT `fk_StructuralComponent_Specimen1`
    FOREIGN KEY (`specimenID` )
    REFERENCES `seriesdb`.`Specimen` (`idSpecimen` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_StructuralComponent_StructuralComponentType1`
    FOREIGN KEY (`SCtypeID` )
    REFERENCES `seriesdb`.`StructuralComponentType` (`idStructuralComponentType` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Structural Components in a Specimen.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Material`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Material` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Material` (
  `idMaterial` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `materialName` VARCHAR(45) NOT NULL ,
  `hasDocument` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Documents.' ,
  PRIMARY KEY (`idMaterial`) ,
  UNIQUE INDEX `uniqueKeys` (`idMaterial` ASC, `materialName` ASC) ,
  UNIQUE INDEX `materialName_UNIQUE` (`materialName` ASC) )
ENGINE = InnoDB
COMMENT = 'Represent a material.';


-- -----------------------------------------------------
-- Table `seriesdb`.`NominalProperty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`NominalProperty` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`NominalProperty` (
  `idNominalProperty` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `nominalPropertyName` VARCHAR(40) NOT NULL ,
  `nominalPropertyValue` DOUBLE NOT NULL ,
  `nominalPropertyUnit` VARCHAR(20) NOT NULL ,
  `observations` VARCHAR(150) NULL COMMENT 'Observations, comments, conditions for the property or the value.' ,
  `valueVectorX` LONGBLOB NULL ,
  `valueVectorY` LONGBLOB NULL ,
  `hasDocument` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Documents.' ,
  `materialID` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`idNominalProperty`) ,
  UNIQUE INDEX `uniqueKeys` (`idNominalProperty` ASC) ,
  INDEX `fk_MaterialProperty_Material1` (`materialID` ASC) ,
  CONSTRAINT `fk_MaterialProperty_Material1`
    FOREIGN KEY (`materialID` )
    REFERENCES `seriesdb`.`Material` (`idMaterial` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Properties for materials';


-- -----------------------------------------------------
-- Table `seriesdb`.`StructuralComponent_Material`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`StructuralComponent_Material` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`StructuralComponent_Material` (
  `idSCMAT` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `StructuralComponent_idStructuralComponent` INT UNSIGNED NOT NULL ,
  `Material_idMaterial` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`idSCMAT`) ,
  INDEX `fk_StructuralElement_has_Material_StructuralElement1` (`StructuralComponent_idStructuralComponent` ASC) ,
  INDEX `fk_StructuralElement_has_Material_Material1` (`Material_idMaterial` ASC) ,
  UNIQUE INDEX `uniqueKeys` (`idSCMAT` ASC) ,
  CONSTRAINT `fk_StructuralElement_has_Material_StructuralElement1`
    FOREIGN KEY (`StructuralComponent_idStructuralComponent` )
    REFERENCES `seriesdb`.`StructuralComponent` (`idStructuralComponent` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_StructuralElement_has_Material_Material1`
    FOREIGN KEY (`Material_idMaterial` )
    REFERENCES `seriesdb`.`Material` (`idMaterial` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Materials in a Struct Comp';


-- -----------------------------------------------------
-- Table `seriesdb`.`ActualMeanProperty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ActualMeanProperty` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ActualMeanProperty` (
  `idActualMeanProperty` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `ActualMeanPropertyName` VARCHAR(40) NOT NULL ,
  `ActualMeanPropertyValue` DOUBLE NULL ,
  `ActualMeanPropertyUnit` VARCHAR(20) NULL ,
  `numberOfSamples` TINYINT UNSIGNED NULL ,
  `observations` VARCHAR(150) NULL COMMENT 'Observations, comments, conditions for the property or the value (f ex after or before which experiment this was observed).' ,
  `valueVectorX` LONGBLOB NULL ,
  `valueVectorY` LONGBLOB NULL ,
  `hasDocument` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Documents.' ,
  `SCMAT_ID` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`idActualMeanProperty`) ,
  UNIQUE INDEX `uniqueKeys` (`idActualMeanProperty` ASC) ,
  INDEX `fk_EffectiveProperties_StructuralElement_Material1` (`SCMAT_ID` ASC) ,
  CONSTRAINT `fk_EffectiveProperties_StructuralElement_Material1`
    FOREIGN KEY (`SCMAT_ID` )
    REFERENCES `seriesdb`.`StructuralComponent_Material` (`idSCMAT` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Material/Struct Com  effective values.';


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputationType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputationType` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputationType` (
  `idExperimentComputationType` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `typeName` VARCHAR(40) NOT NULL ,
  `type` ENUM('EXPERIMENT','COMPUTATION') NOT NULL ,
  PRIMARY KEY (`idExperimentComputationType`) ,
  UNIQUE INDEX `uniqueKeys` (`typeName` ASC) )
ENGINE = InnoDB
COMMENT = 'For the type of experiments';


-- -----------------------------------------------------
-- Table `seriesdb`.`DeviceConfiguration`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DeviceConfiguration` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DeviceConfiguration` (
  `idDeviceConfiguration` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `configurationName` VARCHAR(50) NOT NULL ,
  `configurationNotes` TEXT NULL ,
  PRIMARY KEY (`idDeviceConfiguration`) ,
  UNIQUE INDEX `uniqueKeys` (`configurationName` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`SensorConfiguration`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`SensorConfiguration` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`SensorConfiguration` (
  `idSensorConfiguration` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `configurationName` VARCHAR(50) NOT NULL ,
  `configurationNotes` TEXT NULL ,
  PRIMARY KEY (`idSensorConfiguration`) ,
  UNIQUE INDEX `uniqueKeys` (`configurationName` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation` (
  `idExpComp` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `expCompName` VARCHAR(50) NOT NULL ,
  `class` ENUM('EXPERIMENT','COMPUTATION') NOT NULL DEFAULT 'EXPERIMENT' COMMENT 'Type of element: Experiment or Computation.' ,
  `type` INT UNSIGNED NOT NULL COMMENT 'Type of the experiment (Shaking table, centrifuge, in-situ, hammer, etc)' ,
  `date` TIMESTAMP NOT NULL ,
  `numberOfRepetitions` SMALLINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'The first Experiment/Computation must have a value of 1. The first repetition will have a value of 2, etc' ,
  `peakExcitationValue` DOUBLE UNSIGNED NOT NULL ,
  `peakExcitationUnit` VARCHAR(20) NOT NULL ,
  `SpecimenID` INT UNSIGNED NOT NULL ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  `creator_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_time` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  `DeviceConfigurationID` INT UNSIGNED NULL ,
  `SensorConfigurationID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idExpComp`) ,
  INDEX `fk_Experiment_ExperimentType1` (`type` ASC) ,
  INDEX `fk_Experiment_Specimen1` (`SpecimenID` ASC) ,
  INDEX `classIndex` (`class` ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  INDEX `fk_ExperimentComputation_DeviceConfiguration1` (`DeviceConfigurationID` ASC) ,
  INDEX `fk_ExperimentComputation_SensorConfiguration1` (`SensorConfigurationID` ASC) ,
  CONSTRAINT `fk_Experiment_ExperimentType1`
    FOREIGN KEY (`type` )
    REFERENCES `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Experiment_Specimen1`
    FOREIGN KEY (`SpecimenID` )
    REFERENCES `seriesdb`.`Specimen` (`idSpecimen` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_DeviceConfiguration1`
    FOREIGN KEY (`DeviceConfigurationID` )
    REFERENCES `seriesdb`.`DeviceConfiguration` (`idDeviceConfiguration` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_SensorConfiguration1`
    FOREIGN KEY (`SensorConfigurationID` )
    REFERENCES `seriesdb`.`SensorConfiguration` (`idSensorConfiguration` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_Person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_Person` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_Person` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `Person_idPerson` INT UNSIGNED NOT NULL ,
  `role` ENUM('TEST AGENT','OTHER') NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `Person_idPerson`, `role`) ,
  INDEX `fk_Experiment_has_Person_Experiment1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_Experiment_has_Person_Person1` (`Person_idPerson` ASC) ,
  CONSTRAINT `fk_Experiment_has_Person_Experiment1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Experiment_has_Person_Person1`
    FOREIGN KEY (`Person_idPerson` )
    REFERENCES `seriesdb`.`Person` (`idPerson` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Test agents in an experiment.';


-- -----------------------------------------------------
-- Table `seriesdb`.`SignalTimes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`SignalTimes` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`SignalTimes` (
  `idSignalTimes` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `timeLabel` VARCHAR(25) NOT NULL ,
  `timeVector` LONGBLOB NOT NULL COMMENT 'Vector for the signal times.\n\nOLD: Use the format: VALUE,VALUE,VALUE,...\nUPDATE: Use binary format' ,
  PRIMARY KEY (`idSignalTimes`) )
ENGINE = InnoDB
COMMENT = 'Times for signals. Normally reused for signals.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Sensor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Sensor` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Sensor` (
  `idSensor` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `sensorType` VARCHAR(50) NOT NULL COMMENT 'Sensor type itself.' ,
  `sensorSubtype` VARCHAR(20) NOT NULL COMMENT 'Subtype of the sensor' ,
  `sensorProductName` VARCHAR(40) NOT NULL COMMENT 'Name on the company manufacturer\'s catalogue.' ,
  `sensorLabel` VARCHAR(20) NOT NULL COMMENT 'Local inventory name at the facility.' ,
  `sensorAccuracyValue` DOUBLE UNSIGNED NULL ,
  `sensorAccuracyUnit` VARCHAR(10) NULL ,
  `sensorRangeValue` VARCHAR(10) NULL COMMENT 'Informative value --thus not a number' ,
  `sensorRangeUnit` VARCHAR(10) NULL COMMENT 'Not essential' ,
  `calibration` VARCHAR(10) NULL ,
  `inventoryReference` VARCHAR(30) NULL COMMENT 'Reference in the local inventory or inventory database' ,
  PRIMARY KEY (`idSensor`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`SensorConfiguration_Sensor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`SensorConfiguration_Sensor` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`SensorConfiguration_Sensor` (
  `idSensorConfiguration_Sensor` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `SensorConfiguration_idSensorConfiguration` INT UNSIGNED NOT NULL ,
  `Sensor_idSensor` INT UNSIGNED NOT NULL ,
  `sensorLocation` VARCHAR(35) NOT NULL ,
  `sensorLocationFinal` VARCHAR(35) NULL ,
  `sensorDirection` VARCHAR(45) NOT NULL ,
  `sensorDirectionFinal` VARCHAR(45) NULL ,
  `sensorCoordA_horiz1` DOUBLE NOT NULL ,
  `sensorFinalCoordA_horiz1` DOUBLE NULL ,
  `sensorCoordA_horiz2` DOUBLE NOT NULL ,
  `sensorFinalCoordA_horiz2` DOUBLE NULL ,
  `sensorCoordA_vert` DOUBLE NOT NULL ,
  `sensorFinalCoordA_vert` DOUBLE NULL ,
  `sensorCoordB_horiz1` DOUBLE NULL ,
  `sensorFinalCoordB_horiz1` DOUBLE NULL ,
  `sensorCoordB_horiz2` DOUBLE NULL ,
  `sensorFinalCoordB_horiz2` DOUBLE NULL ,
  `sensorCoordB_vert` DOUBLE NULL ,
  `sensorFinalCoordB_vert` DOUBLE NULL ,
  `notes` MEDIUMTEXT NULL ,
  `sensorPosition` INT UNSIGNED NULL COMMENT 'Document with a drawing: sketch of the specimen and the position of the sensors (sensor position field)' ,
  PRIMARY KEY (`idSensorConfiguration_Sensor`) ,
  INDEX `fk_ExperimentComputation_has_Sensor_Sensor1` (`Sensor_idSensor` ASC) ,
  INDEX `fk_ExperimentComputation_Sensor_Document1` (`sensorPosition` ASC) ,
  INDEX `fk_ExperimentComputation_Sensor_SensorConfiguration1` (`SensorConfiguration_idSensorConfiguration` ASC) ,
  CONSTRAINT `fk_ExperimentComputation_has_Sensor_Sensor1`
    FOREIGN KEY (`Sensor_idSensor` )
    REFERENCES `seriesdb`.`Sensor` (`idSensor` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_Sensor_Document1`
    FOREIGN KEY (`sensorPosition` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_Sensor_SensorConfiguration1`
    FOREIGN KEY (`SensorConfiguration_idSensorConfiguration` )
    REFERENCES `seriesdb`.`SensorConfiguration` (`idSensorConfiguration` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Signals`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Signals` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Signals` (
  `idSignal` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `signalLabel` VARCHAR(25) NOT NULL ,
  `attribute` VARCHAR(30) NOT NULL COMMENT 'Characterizes the magnitude of the signal' ,
  `physicalQuantity` VARCHAR(20) NOT NULL COMMENT 'Possible ENUM field' ,
  `type` ENUM('COMPUTED','MEASURED') NOT NULL ,
  `unit` VARCHAR(10) NOT NULL ,
  `location` VARCHAR(35) NULL ,
  `additionalParameter` VARCHAR(60) NULL ,
  `signalValuesURI` VARCHAR(255) NOT NULL COMMENT 'File with the signal values' ,
  `signalValuesFormat` ENUM('SERIESBINARY','MATLAB','OTH') NOT NULL DEFAULT 'SERIESBINARY' COMMENT 'Format of the file with the signal values' ,
  `valueVector` LONGBLOB NOT NULL COMMENT 'Vector for the signal values\n\nOLD: Use the format: VALUE,VALUE,VALUE,...\nUPDATE: Use binary format' ,
  `complexValue` LONGBLOB NULL COMMENT 'Optional if the signal is a complex number.\n\nOLD: Use the format: VALUE,VALUE,VALUE,...\nUPDATE: Use binary format\n\n' ,
  `labTimeVectorID` INT UNSIGNED NOT NULL ,
  `accTimeVectorID` INT UNSIGNED NOT NULL ,
  `sensorConfig_sensorID` INT UNSIGNED NULL DEFAULT NULL COMMENT 'Related Sensor, used for Experiments (computations have no associated sensor)' ,
  `expCompID` INT UNSIGNED NULL DEFAULT NULL COMMENT 'For OUTPUT signals: Related Experiment. \"NULL\" means it is not an output signal.' ,
  `repetitionNumber` SMALLINT UNSIGNED NULL COMMENT 'For OUTPUT signals: repetition number for the Experiment/Computation   \"expCompID\"' ,
  `originalSignalFileLocation` ENUM('INTERNAL','EXTERNAL','ENCLOSED') NULL DEFAULT 'INTERNAL' ,
  `originalSignalFileURI` VARCHAR(255) NULL ,
  `enclosedOriginalSignalFile` LONGBLOB NULL ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  `creator_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_idUser` INT UNSIGNED NOT NULL ,
  `lastModification_time` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  `vectorFormat` VARCHAR(300) NOT NULL ,
  PRIMARY KEY (`idSignal`) ,
  INDEX `fk_Signal_SignalTimes1` (`labTimeVectorID` ASC) ,
  INDEX `fk_Signal_Experiment1` (`expCompID` ASC) ,
  INDEX `fk_Signal_SignalTimes2` (`accTimeVectorID` ASC) ,
  INDEX `fk_Signal_SensorConfiguration_Sensor1` (`sensorConfig_sensorID` ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  CONSTRAINT `fk_Signal_SignalTimes1`
    FOREIGN KEY (`labTimeVectorID` )
    REFERENCES `seriesdb`.`SignalTimes` (`idSignalTimes` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Signal_Experiment1`
    FOREIGN KEY (`expCompID` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Signal_SignalTimes2`
    FOREIGN KEY (`accTimeVectorID` )
    REFERENCES `seriesdb`.`SignalTimes` (`idSignalTimes` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Signal_SensorConfiguration_Sensor1`
    FOREIGN KEY (`sensorConfig_sensorID` )
    REFERENCES `seriesdb`.`SensorConfiguration_Sensor` (`idSensorConfiguration_Sensor` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`OriginalLoadingSignal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`OriginalLoadingSignal` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`OriginalLoadingSignal` (
  `idOriginalLoadingSignal` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `originalLoadingName` VARCHAR(75) NOT NULL ,
  `nature` ENUM('NATURAL','ARTIFICIAL','NATURAL-MODIFIED','GENERATED') NOT NULL ,
  `source` VARCHAR(60) NOT NULL COMMENT 'Source of the input signal, like for example:\n- a station and direction\n- a reference to a code of practice\n- the name of a finite element package or simulation\n- the name of some software (e.g. matlab)\n- the name of a signal generator' ,
  `peakExcitationValue` DOUBLE NOT NULL ,
  `peakExcitationUnit` VARCHAR(20) NOT NULL ,
  `hasDocument` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Documents.' ,
  `signalID` INT UNSIGNED NOT NULL COMMENT 'Signal Element' ,
  PRIMARY KEY (`idOriginalLoadingSignal`) ,
  INDEX `fk_OriginalInputSignal_Signal1` (`signalID` ASC) ,
  CONSTRAINT `fk_OriginalInputSignal_Signal1`
    FOREIGN KEY (`signalID` )
    REFERENCES `seriesdb`.`Signals` (`idSignal` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Original inputs time-histories and related info.';


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_Document` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  `documentType` ENUM('BOUNDARYCONDITION','EXPLOGOBSERVATION','MMOBSERVATION') NOT NULL COMMENT '- Experiment Log Observation field\n- Multi-media Observations' ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `Document_idDocument`, `documentType`) ,
  INDEX `fk_Experiment_has_Document_Experiment1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_Experiment_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_Experiment_has_Document_Experiment1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Experiment_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'For Experiment\'s input files, Boundary conditions...';


-- -----------------------------------------------------
-- Table `seriesdb`.`Scaling_props`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Scaling_props` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Scaling_props` (
  `idScaling_props` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `scaledPropertyName` VARCHAR(25) NOT NULL ,
  PRIMARY KEY (`idScaling_props`) ,
  UNIQUE INDEX `uniqueKeys` (`scaledPropertyName` ASC) )
ENGINE = InnoDB
COMMENT = 'Properties for Scalation. This table is not essential';


-- -----------------------------------------------------
-- Table `seriesdb`.`Scaling`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Scaling` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Scaling` (
  `idScaling` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `scaledProperty` INT UNSIGNED NOT NULL COMMENT 'Lenght and Time \"should\" appear' ,
  `PrototypeModel_ratio` DOUBLE UNSIGNED NOT NULL COMMENT 'Ratio of scalation. Same units as originally.' ,
  `specimenID` INT UNSIGNED NOT NULL COMMENT 'Specimen that has the scalation.' ,
  PRIMARY KEY (`idScaling`) ,
  INDEX `fk_Scalation_Specimen1` (`specimenID` ASC) ,
  INDEX `fk_Scalation_Scalation_props1` (`scaledProperty` ASC) ,
  CONSTRAINT `fk_Scalation_Specimen1`
    FOREIGN KEY (`specimenID` )
    REFERENCES `seriesdb`.`Specimen` (`idSpecimen` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Scalation_Scalation_props1`
    FOREIGN KEY (`scaledProperty` )
    REFERENCES `seriesdb`.`Scaling_props` (`idScaling_props` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Scale factor in a scaled specimen';


-- -----------------------------------------------------
-- Table `seriesdb`.`DetailedLoadingCharacteristic`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DetailedLoadingCharacteristic` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DetailedLoadingCharacteristic` (
  `idDetailedLoadingCharacteristic` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `nominalLoadingName` VARCHAR(40) NOT NULL ,
  `additionalParameter` VARCHAR(100) NULL ,
  `notes` TEXT NULL ,
  PRIMARY KEY (`idDetailedLoadingCharacteristic`) ,
  UNIQUE INDEX `nominalName` (`nominalLoadingName` ASC) )
ENGINE = InnoDB
COMMENT = 'It collects all the information that characterizes the exp';


-- -----------------------------------------------------
-- Table `seriesdb`.`DeviceType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DeviceType` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DeviceType` (
  `idDeviceType` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `deviceTypeName` VARCHAR(50) NOT NULL ,
  PRIMARY KEY (`idDeviceType`) ,
  UNIQUE INDEX `uniqueKeys` (`deviceTypeName` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Device`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Device` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Device` (
  `idDevice` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `deviceType` INT UNSIGNED NOT NULL COMMENT 'Device itself: actuator, servo-valve, etc' ,
  `deviceSubtype` VARCHAR(20) NOT NULL COMMENT 'Subtype of the device:\nFor actuators: symmetric, telescopic... \nFor servo-valves: proportional...\nFor controllers: analogical, digital...' ,
  `deviceProductName` VARCHAR(40) NOT NULL COMMENT 'Name on the company manufacturer\'s catalogue.' ,
  `deviceLabel` VARCHAR(20) NOT NULL COMMENT 'Local inventory name at the facility.' ,
  `strokeCapacityValue` DOUBLE UNSIGNED NOT NULL ,
  `strokeCapacityUnit` VARCHAR(10) NOT NULL ,
  `forceCapacityValue` DOUBLE NOT NULL ,
  `forceCapacityUnit` VARCHAR(10) NOT NULL ,
  `calibration` VARCHAR(10) NOT NULL ,
  `notes` MEDIUMTEXT NULL ,
  `inventoryReference` VARCHAR(30) NULL COMMENT 'Reference in the local inventory or inventory database' ,
  PRIMARY KEY (`idDevice`) ,
  INDEX `fk_Device_DeviceType1` (`deviceType` ASC) ,
  CONSTRAINT `fk_Device_DeviceType1`
    FOREIGN KEY (`deviceType` )
    REFERENCES `seriesdb`.`DeviceType` (`idDeviceType` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_Image` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `Image_idImage` INT UNSIGNED NOT NULL ,
  `imageType` ENUM('BOUNDARYCONDITION','MMGRAPHIC','MMPHOTO','MM3DPLOT') NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `Image_idImage`, `imageType`) ,
  INDEX `fk_Experiment_has_Image_Experiment1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_Experiment_has_Image_Image1` (`Image_idImage` ASC) ,
  CONSTRAINT `fk_Experiment_has_Image_Experiment1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Experiment_has_Image_Image1`
    FOREIGN KEY (`Image_idImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'For Boundary conditions';


-- -----------------------------------------------------
-- Table `seriesdb`.`Video`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Video` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Video` (
  `idVideo` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `videoName` VARCHAR(50) NOT NULL COMMENT 'Name for the video.' ,
  `videoDate` TIMESTAMP NULL COMMENT 'Date when the video was taken.' ,
  `videoFormat` ENUM('MPG','AVI','MOV','FLV','ZIP','RAR','WEB','OTH') NOT NULL ,
  `videoLocation` ENUM('INTERNAL','EXTERNAL','ENCLOSED') NOT NULL DEFAULT 'INTERNAL' COMMENT 'INTERNAL:vid in local site (EX:/series/myvid.mpg or  http://www.ox.ac.uk/series/myvid.mpg)\nEXTERNAL:vid in external site,access protocol (http://, ftp://, etc) must be specified.\nENCLOSED:vid embedded in the db,col:\"enclosedVideo\".' ,
  `videoURI` VARCHAR(255) NULL COMMENT 'Video location (Uniform Resource Identifier). It can be in the local machine or in a remote one.' ,
  `enclosedVideo` LONGBLOB NULL COMMENT 'Optional to store the video in the DB (warning: size might not be enough)' ,
  `videoSize` DOUBLE UNSIGNED NOT NULL COMMENT 'Video size in KB (should admit not only whole numbers).' ,
  `summary` TINYTEXT NULL COMMENT 'Brief description of the video.' ,
  `hashValue` TINYBLOB NOT NULL COMMENT 'File CRC to avoid duplicates.' ,
  `downloadAllowed` ENUM('YES','NO') NOT NULL DEFAULT 'YES' ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  PRIMARY KEY (`idVideo`) ,
  UNIQUE INDEX `hash_UNIQUE` (`hashValue`(20) ASC) ,
  INDEX `hash_INDEX` (`hashValue`(20) ASC) ,
  INDEX `privacy_INDEX` (`privacy` ASC) ,
  INDEX `download_INDEX` (`downloadAllowed` ASC) )
ENGINE = InnoDB
COMMENT = 'Videos.';


-- -----------------------------------------------------
-- Table `seriesdb`.`Software`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Software` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Software` (
  `idSoftware` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `softwareName` VARCHAR(45) NOT NULL COMMENT 'Name of the program.' ,
  `softwareURI` VARCHAR(255) NOT NULL COMMENT 'Software location (Uniform Resource Identifier). It can be in the local machine or in a remote one.' ,
  `softwareVersion` VARCHAR(15) NOT NULL DEFAULT 0 COMMENT 'Version of the program.' ,
  `hashValue` TINYBLOB NOT NULL COMMENT 'CRC of the program. It allows to avoid storing the same program several times.' ,
  PRIMARY KEY (`idSoftware`) ,
  INDEX `hashValue_INDEX` (`hashValue`(20) ASC) ,
  UNIQUE INDEX `hashValue_UNIQUE` (`hashValue`(20) ASC) )
ENGINE = InnoDB
COMMENT = 'Software used in a Test.';


-- -----------------------------------------------------
-- Table `seriesdb`.`ComputerSystem`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ComputerSystem` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ComputerSystem` (
  `idComputerSystem` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `softwareName` VARCHAR(45) NOT NULL ,
  `softwareVersion` VARCHAR(15) NOT NULL ,
  PRIMARY KEY (`idComputerSystem`) )
ENGINE = InnoDB
COMMENT = 'Configuration of Computations';


-- -----------------------------------------------------
-- Table `seriesdb`.`MeshModel`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`MeshModel` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`MeshModel` (
  `idMeshModel` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `meshModelName` VARCHAR(50) NOT NULL ,
  `materialSymmetryType` ENUM('ISOTROPIC', 'ORTHOTROPIC','ANISOTROPIC', 'UNIAXIAL') NOT NULL ,
  `materialNonlinearity` VARCHAR(20) NOT NULL ,
  `hasDocument` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Documents.' ,
  `hasImage` ENUM('YES','NO') NOT NULL DEFAULT 'NO' COMMENT 'This col helps to improve performance in tables that are less likely to have associated Images.' ,
  `expCompID` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`idMeshModel`) ,
  INDEX `fk_MeshModel_Experiment1` (`expCompID` ASC) ,
  UNIQUE INDEX `meshModelName_UNIQUE` (`meshModelName` ASC) ,
  CONSTRAINT `fk_MeshModel_Experiment1`
    FOREIGN KEY (`expCompID` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`OriginalLoadingSignal_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`OriginalLoadingSignal_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`OriginalLoadingSignal_Document` (
  `OriginalLoadingSignal_idOriginalLoadingSignal` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`OriginalLoadingSignal_idOriginalLoadingSignal`, `Document_idDocument`) ,
  INDEX `fk_OriginalLoadingSignal_has_Document_OriginalLoadingSignal1` (`OriginalLoadingSignal_idOriginalLoadingSignal` ASC) ,
  INDEX `fk_OriginalLoadingSignal_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_OriginalLoadingSignal_has_Document_OriginalLoadingSignal1`
    FOREIGN KEY (`OriginalLoadingSignal_idOriginalLoadingSignal` )
    REFERENCES `seriesdb`.`OriginalLoadingSignal` (`idOriginalLoadingSignal` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_OriginalLoadingSignal_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`MeshModel_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`MeshModel_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`MeshModel_Document` (
  `MeshModel_idMeshModel` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`MeshModel_idMeshModel`, `Document_idDocument`) ,
  INDEX `fk_MeshModel_has_Document_MeshModel1` (`MeshModel_idMeshModel` ASC) ,
  INDEX `fk_MeshModel_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_MeshModel_has_Document_MeshModel1`
    FOREIGN KEY (`MeshModel_idMeshModel` )
    REFERENCES `seriesdb`.`MeshModel` (`idMeshModel` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MeshModel_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'For Additional Documentation';


-- -----------------------------------------------------
-- Table `seriesdb`.`NominalProperty_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`NominalProperty_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`NominalProperty_Document` (
  `NominalProperty_idNominalProperty` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  `documentType` ENUM('MATERIALCURVE','ADDITIONALDOC') NOT NULL ,
  PRIMARY KEY (`NominalProperty_idNominalProperty`, `Document_idDocument`, `documentType`) ,
  INDEX `fk_NominalProperty_has_Document_NominalProperty1` (`NominalProperty_idNominalProperty` ASC) ,
  INDEX `fk_NominalProperty_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_NominalProperty_has_Document_NominalProperty1`
    FOREIGN KEY (`NominalProperty_idNominalProperty` )
    REFERENCES `seriesdb`.`NominalProperty` (`idNominalProperty` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_NominalProperty_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ActualMeanProperty_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ActualMeanProperty_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ActualMeanProperty_Document` (
  `ActualMeanProperty_idActualMeanProperty` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  `documentType` ENUM('MATERIALCURVE','ADDITIONALDOC') NOT NULL ,
  PRIMARY KEY (`ActualMeanProperty_idActualMeanProperty`, `Document_idDocument`, `documentType`) ,
  INDEX `fk_ActualMeanProperty_has_Document_ActualMeanProperty1` (`ActualMeanProperty_idActualMeanProperty` ASC) ,
  INDEX `fk_ActualMeanProperty_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_ActualMeanProperty_has_Document_ActualMeanProperty1`
    FOREIGN KEY (`ActualMeanProperty_idActualMeanProperty` )
    REFERENCES `seriesdb`.`ActualMeanProperty` (`idActualMeanProperty` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ActualMeanProperty_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`MeshModel_Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`MeshModel_Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`MeshModel_Image` (
  `MeshModel_idMeshModel` INT UNSIGNED NOT NULL ,
  `Image_idImage` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`MeshModel_idMeshModel`, `Image_idImage`) ,
  INDEX `fk_MeshModel_has_Image_MeshModel1` (`MeshModel_idMeshModel` ASC) ,
  INDEX `fk_MeshModel_has_Image_Image1` (`Image_idImage` ASC) ,
  CONSTRAINT `fk_MeshModel_has_Image_MeshModel1`
    FOREIGN KEY (`MeshModel_idMeshModel` )
    REFERENCES `seriesdb`.`MeshModel` (`idMeshModel` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MeshModel_has_Image_Image1`
    FOREIGN KEY (`Image_idImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'For Undeformed shape picture';


-- -----------------------------------------------------
-- Table `seriesdb`.`MeshModel_Material`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`MeshModel_Material` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`MeshModel_Material` (
  `MeshModel_idMeshModel` INT UNSIGNED NOT NULL ,
  `Material_idMaterial` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`MeshModel_idMeshModel`, `Material_idMaterial`) ,
  INDEX `fk_MeshModel_has_Material_MeshModel1` (`MeshModel_idMeshModel` ASC) ,
  INDEX `fk_MeshModel_has_Material_Material1` (`Material_idMaterial` ASC) ,
  CONSTRAINT `fk_MeshModel_has_Material_MeshModel1`
    FOREIGN KEY (`MeshModel_idMeshModel` )
    REFERENCES `seriesdb`.`MeshModel` (`idMeshModel` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MeshModel_has_Material_Material1`
    FOREIGN KEY (`Material_idMaterial` )
    REFERENCES `seriesdb`.`Material` (`idMaterial` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_Video`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_Video` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_Video` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `Video_idVideo` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `Video_idVideo`) ,
  INDEX `fk_Experiment_has_Video_Experiment1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_Experiment_has_Video_Video1` (`Video_idVideo` ASC) ,
  CONSTRAINT `fk_Experiment_has_Video_Experiment1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Experiment_has_Video_Video1`
    FOREIGN KEY (`Video_idVideo` )
    REFERENCES `seriesdb`.`Video` (`idVideo` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ServiceRecord`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ServiceRecord` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ServiceRecord` (
  `idServiceRecord` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `source` VARCHAR(40) NOT NULL COMMENT 'Source computer to call the WS (IP/NS of computer accessing the WS)' ,
  `startOpTime` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' ,
  `operationName` VARCHAR(100) NOT NULL ,
  `operationCompleted` ENUM('YES','NO') NOT NULL DEFAULT 'NO' ,
  `endOpTime` TIMESTAMP NULL DEFAULT NULL ,
  PRIMARY KEY (`idServiceRecord`) )
ENGINE = InnoDB
COMMENT = 'Record of WS activity-Clear this table every 2months';


-- -----------------------------------------------------
-- Table `seriesdb`.`Partner`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Partner` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Partner` (
  `idPartner` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `addrInformation` INT NOT NULL COMMENT 'IP information' ,
  `NSInformation` VARCHAR(50) NULL COMMENT 'Name Server information. (Suggested to try to use this before the addrInformation).' ,
  `notes` TEXT NULL ,
  `institutionID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idPartner`) ,
  INDEX `fk_Partner_Institution1` (`institutionID` ASC) ,
  CONSTRAINT `fk_Partner_Institution1`
    FOREIGN KEY (`institutionID` )
    REFERENCES `seriesdb`.`Institution` (`idInstitution` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Testing`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Testing` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Testing` (
  `idTesting` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `text` VARCHAR(20) NOT NULL ,
  PRIMARY KEY (`idTesting`) )
ENGINE = InnoDB
COMMENT = 'For testing purpose.';


-- -----------------------------------------------------
-- Table `seriesdb`.`UpdateRecord`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`UpdateRecord` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`UpdateRecord` (
  `idUpdateRecord` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `level` ENUM('PROJECT','SPECIMEN','EXPERIMENTCOMPUTATION','SIGNAL','DOCUMENT') NOT NULL ,
  `objectName` VARCHAR(25) NOT NULL ,
  `objectID` INT UNSIGNED NOT NULL ,
  `auxID` INT UNSIGNED NULL COMMENT 'Some objects might need to store an auxiliar ID (parent ID, etc)' ,
  `operation` ENUM('NEW','UPDATE','DELETE') NOT NULL ,
  `updateDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  `privacy` ENUM('PRIVATE','PARTNER','PUBLIC') NOT NULL DEFAULT 'PRIVATE' ,
  PRIMARY KEY (`idUpdateRecord`) ,
  INDEX `updateDate` (`updateDate` ASC) ,
  INDEX `updateOperation` (`operation` ASC) ,
  INDEX `updateLevel` (`level` ASC) )
ENGINE = InnoDB
COMMENT = 'For updating process';


-- -----------------------------------------------------
-- Table `seriesdb`.`ProjectKeywords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ProjectKeywords` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ProjectKeywords` (
  `idProjectKeywords` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `keywordName` VARCHAR(50) NOT NULL ,
  PRIMARY KEY (`idProjectKeywords`) ,
  UNIQUE INDEX `uniqueKeys` (`keywordName` ASC) )
ENGINE = InnoDB
COMMENT = 'Keywords to define a proj';


-- -----------------------------------------------------
-- Table `seriesdb`.`Project_ProjectKeywords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Project_ProjectKeywords` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Project_ProjectKeywords` (
  `Project_idProject` INT UNSIGNED NOT NULL ,
  `ProjectKeywords_idProjectKeywords` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`Project_idProject`, `ProjectKeywords_idProjectKeywords`) ,
  INDEX `fk_Project_has_ProjectKeywords_Project1` (`Project_idProject` ASC) ,
  INDEX `fk_Project_has_ProjectKeywords_ProjectKeywords1` (`ProjectKeywords_idProjectKeywords` ASC) ,
  CONSTRAINT `fk_Project_has_ProjectKeywords_Project1`
    FOREIGN KEY (`Project_idProject` )
    REFERENCES `seriesdb`.`Project` (`idProject` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Project_has_ProjectKeywords_ProjectKeywords1`
    FOREIGN KEY (`ProjectKeywords_idProjectKeywords` )
    REFERENCES `seriesdb`.`ProjectKeywords` (`idProjectKeywords` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`SensorConfigurationSensor_Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`SensorConfigurationSensor_Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`SensorConfigurationSensor_Image` (
  `SensorConfiguration_Sensor` INT UNSIGNED NOT NULL ,
  `Image_idImage` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`SensorConfiguration_Sensor`, `Image_idImage`) ,
  INDEX `fk_ExperimentComputation_Sensor_has_Image_ExperimentComputati1` (`SensorConfiguration_Sensor` ASC) ,
  INDEX `fk_ExperimentComputation_Sensor_has_Image_Image1` (`Image_idImage` ASC) ,
  CONSTRAINT `fk_ExperimentComputation_Sensor_has_Image_ExperimentComputati1`
    FOREIGN KEY (`SensorConfiguration_Sensor` )
    REFERENCES `seriesdb`.`SensorConfiguration_Sensor` (`idSensorConfiguration_Sensor` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_Sensor_has_Image_Image1`
    FOREIGN KEY (`Image_idImage` )
    REFERENCES `seriesdb`.`Image` (`idImage` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Images of a sensor';


-- -----------------------------------------------------
-- Table `seriesdb`.`StructuralComponent_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`StructuralComponent_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`StructuralComponent_Document` (
  `StructuralComponent_idStructuralComponent` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`StructuralComponent_idStructuralComponent`, `Document_idDocument`) ,
  INDEX `fk_StructuralComponent_has_Document_StructuralComponent1` (`StructuralComponent_idStructuralComponent` ASC) ,
  INDEX `fk_StructuralComponent_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_StructuralComponent_has_Document_StructuralComponent1`
    FOREIGN KEY (`StructuralComponent_idStructuralComponent` )
    REFERENCES `seriesdb`.`StructuralComponent` (`idStructuralComponent` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_StructuralComponent_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Additional Documentation';


-- -----------------------------------------------------
-- Table `seriesdb`.`Material_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Material_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Material_Document` (
  `Material_idMaterial` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`Material_idMaterial`, `Document_idDocument`) ,
  INDEX `fk_Material_has_Document_Material1` (`Material_idMaterial` ASC) ,
  INDEX `fk_Material_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_Material_has_Document_Material1`
    FOREIGN KEY (`Material_idMaterial` )
    REFERENCES `seriesdb`.`Material` (`idMaterial` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Material_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'Additional documentation';


-- -----------------------------------------------------
-- Table `seriesdb`.`File`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`File` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`File` (
  `idFile` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `fileName` VARCHAR(100) NOT NULL ,
  `fileDate` TIMESTAMP NOT NULL ,
  `fileFormat` VARCHAR(50) NOT NULL ,
  `Description` MEDIUMTEXT NULL ,
  `fileLocation` ENUM('INTERNAL','EXTERNAL','ENCLOSED') NOT NULL DEFAULT 'INTERNAL' COMMENT 'INTERNAL:file in local site (EX:/series/mydocument.pdf or  http://www.ox.ac.uk/series/mydocument.pdf)\nEXTERNAL:file in external site,access protocol (http://, ftp://, etc) must be specified.\nENCLOSED:file embedded in the db,col:\"enclosedFile\".' ,
  `fileURI` VARCHAR(255) NULL COMMENT 'File location (Uniform Resource Identifier). It can be in the local machine or in a remote one.' ,
  `enclosedFile` LONGBLOB NULL ,
  `hashValue` TINYBLOB NOT NULL COMMENT 'File CRC to avoid duplicates.' ,
  PRIMARY KEY (`idFile`) ,
  UNIQUE INDEX `hashValue_UNIQUE` (`hashValue`(20) ASC) ,
  INDEX `hashValue_INDEX` (`hashValue`(20) ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_File`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_File` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_File` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `File_idFile` INT UNSIGNED NOT NULL ,
  `fileType` ENUM('INPUTFILE','RAWDATA','POSTPROCESSING') NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `File_idFile`, `fileType`) ,
  INDEX `fk_ExperimentComputation_has_File_ExperimentComputation1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_ExperimentComputation_has_File_File1` (`File_idFile` ASC) ,
  CONSTRAINT `fk_ExperimentComputation_has_File_ExperimentComputation1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_has_File_File1`
    FOREIGN KEY (`File_idFile` )
    REFERENCES `seriesdb`.`File` (`idFile` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`DeviceConfiguration_Device`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DeviceConfiguration_Device` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DeviceConfiguration_Device` (
  `idDeviceConfigurationDevice` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `DeviceConfiguration_idDeviceConfiguration` INT UNSIGNED NOT NULL ,
  `Device_idDevice` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`idDeviceConfigurationDevice`) ,
  INDEX `fk_DeviceConfiguration_has_Device_DeviceConfiguration1` (`DeviceConfiguration_idDeviceConfiguration` ASC) ,
  INDEX `fk_DeviceConfiguration_has_Device_Device1` (`Device_idDevice` ASC) ,
  CONSTRAINT `fk_DeviceConfiguration_has_Device_DeviceConfiguration1`
    FOREIGN KEY (`DeviceConfiguration_idDeviceConfiguration` )
    REFERENCES `seriesdb`.`DeviceConfiguration` (`idDeviceConfiguration` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DeviceConfiguration_has_Device_Device1`
    FOREIGN KEY (`Device_idDevice` )
    REFERENCES `seriesdb`.`Device` (`idDevice` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`DeviceRelation`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DeviceRelation` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DeviceRelation` (
  `DeviceConfiguration_DeviceID` INT UNSIGNED NOT NULL ,
  `Parent_DeviceID` INT UNSIGNED NOT NULL ,
  `Child_DeviceID` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`DeviceConfiguration_DeviceID`, `Parent_DeviceID`, `Child_DeviceID`) ,
  INDEX `fk_DeviceRelation_Device1` (`Parent_DeviceID` ASC) ,
  INDEX `fk_DeviceRelation_Device2` (`Child_DeviceID` ASC) ,
  INDEX `fk_DeviceRelation_DeviceConfiguration_Device1` (`DeviceConfiguration_DeviceID` ASC) ,
  CONSTRAINT `fk_DeviceRelation_Device1`
    FOREIGN KEY (`Parent_DeviceID` )
    REFERENCES `seriesdb`.`Device` (`idDevice` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DeviceRelation_Device2`
    FOREIGN KEY (`Child_DeviceID` )
    REFERENCES `seriesdb`.`Device` (`idDevice` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DeviceRelation_DeviceConfiguration_Device1`
    FOREIGN KEY (`DeviceConfiguration_DeviceID` )
    REFERENCES `seriesdb`.`DeviceConfiguration_Device` (`idDeviceConfigurationDevice` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
COMMENT = 'To link devices each other';


-- -----------------------------------------------------
-- Table `seriesdb`.`DBinfo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DBinfo` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DBinfo` (
  `idDBinfo` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `databaseVersion` VARCHAR(60) NOT NULL COMMENT 'Version of the Database' ,
  `databaseDate` TIMESTAMP NOT NULL DEFAULT '2000-01-01 00:00:00' COMMENT 'Time the database version was released' ,
  `databaseUpdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Time the database was installed/updated' ,
  `notes` VARCHAR(200) NOT NULL ,
  `cacheVersion` VARCHAR(30) NOT NULL DEFAULT 'No cache' ,
  PRIMARY KEY (`idDBinfo`) )
ENGINE = InnoDB
COMMENT = 'Information about the Database';


-- -----------------------------------------------------
-- Table `seriesdb`.`Device_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Device_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Device_Document` (
  `Device_idDevice` INT UNSIGNED NOT NULL ,
  `Document_idDocument` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`Device_idDevice`, `Document_idDocument`) ,
  INDEX `fk_Device_has_Document_Device1` (`Device_idDevice` ASC) ,
  INDEX `fk_Device_has_Document_Document1` (`Document_idDocument` ASC) ,
  CONSTRAINT `fk_Device_has_Document_Device1`
    FOREIGN KEY (`Device_idDevice` )
    REFERENCES `seriesdb`.`Device` (`idDevice` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Device_has_Document_Document1`
    FOREIGN KEY (`Document_idDocument` )
    REFERENCES `seriesdb`.`Document` (`idDocument` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_ComputerSystem`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_ComputerSystem` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_ComputerSystem` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `ComputerSystem_idComputerSystem` INT UNSIGNED NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `ComputerSystem_idComputerSystem`) ,
  INDEX `fk_ExperimentComputation_has_ComputerSystem_ExperimentComputa1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_ExperimentComputation_has_ComputerSystem_ComputerSystem1` (`ComputerSystem_idComputerSystem` ASC) ,
  CONSTRAINT `fk_ExperimentComputation_has_ComputerSystem_ExperimentComputa1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_has_ComputerSystem_ComputerSystem1`
    FOREIGN KEY (`ComputerSystem_idComputerSystem` )
    REFERENCES `seriesdb`.`ComputerSystem` (`idComputerSystem` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Project`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Project` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Project` (
  `idCache_Project` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idProject` INT UNSIGNED NULL ,
  `projectTitle` VARCHAR(130) NULL ,
  `acronym` VARCHAR(15) NULL ,
  `projectStartDate` TIMESTAMP NULL ,
  `projectEndDate` TIMESTAMP NULL ,
  `projectDescription` TEXT NULL ,
  `projectStatus` ENUM('NEW','FORESEEN','IN PROGRESS','FINISHED') NULL ,
  `fundingOrganization` VARCHAR(100) NULL ,
  `projectMainFocus` VARCHAR(100) NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  PRIMARY KEY (`idCache_Project`) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Person` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Person` (
  `idCache_Person` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idPerson` INT UNSIGNED NULL ,
  `familyName` VARCHAR(80) NULL ,
  `role` VARCHAR(30) NULL ,
  `institutionName` VARCHAR(100) NULL ,
  `institutionAcronym` VARCHAR(15) NULL ,
  `projectID` INT UNSIGNED NULL DEFAULT NULL ,
  `expCompID` INT UNSIGNED NULL DEFAULT NULL ,
  PRIMARY KEY (`idCache_Person`) ,
  INDEX `projectIDindex` (`projectID` ASC) ,
  INDEX `expCompIDindex` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Infrastructure`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Infrastructure` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Infrastructure` (
  `idCache_Infrastructure` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `infrastructureName` VARCHAR(40) NULL ,
  `facilityName` VARCHAR(40) NULL ,
  `location` VARCHAR(20) NULL ,
  `projectID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_Infrastructure`) ,
  INDEX `projectIDindex` (`projectID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_ProjectKeywords`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_ProjectKeywords` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_ProjectKeywords` (
  `idCache_ProjectKeywords` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `keywordName` VARCHAR(50) NULL ,
  `projectID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_ProjectKeywords`) ,
  INDEX `projectIDindex` (`projectID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Info`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Info` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Info` (
  `idCache_Info` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `creationTime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Time when the cache was updated' ,
  `cacheHash` CHAR(40) NOT NULL COMMENT 'Unique code of cache data version.Normally,working with creationTime will be faster and enough.This hash can be made with additnal info' ,
  `current` ENUM('YES','NO') NOT NULL DEFAULT 'YES' ,
  PRIMARY KEY (`idCache_Info`) ,
  INDEX `currentIndex` (`current` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Specimen`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Specimen` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Specimen` (
  `idCache_Specimen` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idSpecimen` INT UNSIGNED NULL ,
  `specimenName` VARCHAR(45) NULL ,
  `max_Length` DOUBLE NULL ,
  `max_Width` DOUBLE NULL ,
  `max_Height` DOUBLE NULL ,
  `max_Depth` DOUBLE NULL ,
  `specimenMass` DOUBLE NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `projectID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_Specimen`) ,
  INDEX `projectIDindex` (`projectID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Scaling`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Scaling` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Scaling` (
  `idCache_Scaling` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `scaledPropertyName` VARCHAR(25) NULL ,
  `PrototypeModel_ratio` DOUBLE NULL ,
  `specimenID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_Scaling`) ,
  INDEX `specimenIDindex` (`specimenID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_StructuralComponent`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_StructuralComponent` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_StructuralComponent` (
  `idCache_StructuralComponent` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `structuralComponentName` VARCHAR(70) NULL ,
  `typeName` VARCHAR(90) NULL ,
  `materialDescription` VARCHAR(100) NULL ,
  `specimenID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_StructuralComponent`) ,
  INDEX `SpecimenIDindex` (`specimenID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Material`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Material` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Material` (
  `idCache_Material` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idMaterial` INT UNSIGNED NULL ,
  `materialName` VARCHAR(45) NULL ,
  `StructuralComponentID` INT UNSIGNED NULL DEFAULT NULL ,
  `meshModelID` INT UNSIGNED NULL DEFAULT NULL ,
  PRIMARY KEY (`idCache_Material`) ,
  INDEX `StructuralComponentIDindex` (`StructuralComponentID` ASC) ,
  INDEX `meshModelIDindex` (`meshModelID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_NominalProperty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_NominalProperty` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_NominalProperty` (
  `idCache_NominalProperty` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `nominalPropertyName` VARCHAR(40) NULL ,
  `nominalPropertyValue` DOUBLE NULL ,
  `nominalPropertyUnit` VARCHAR(20) NULL ,
  `observations` VARCHAR(150) NULL ,
  `valueVectorY` LONGBLOB NULL ,
  `valueVectorX` LONGBLOB NULL ,
  `materialID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_NominalProperty`) ,
  INDEX `materialIDindex` (`materialID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_ActualMeanProperty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_ActualMeanProperty` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_ActualMeanProperty` (
  `idCache_ActualMeanProperty` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `ActualMeanPropertyName` VARCHAR(40) NULL ,
  `ActualMeanPropertyValue` DOUBLE NULL ,
  `ActualMeanPropertyUnit` VARCHAR(20) NULL ,
  `numberOfSamples` TINYINT NULL ,
  `observations` VARCHAR(150) NULL ,
  `valueVectorX` LONGBLOB NULL ,
  `valueVectorY` LONGBLOB NULL ,
  `Cache_MaterialID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_ActualMeanProperty`) ,
  INDEX `Cache_MaterialIDindex` (`Cache_MaterialID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_ExperimentComputation`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_ExperimentComputation` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_ExperimentComputation` (
  `idCache_ExperimentComputation` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idExpComp` INT UNSIGNED NULL ,
  `expCompName` VARCHAR(50) NULL ,
  `class` ENUM('EXPERIMENT','COMPUTATION') NULL ,
  `typeName` VARCHAR(40) NULL ,
  `date` TIMESTAMP NULL ,
  `numberOfRepetitions` SMALLINT UNSIGNED NULL ,
  `loadingCoefficient` SMALLINT UNSIGNED NULL ,
  `peakExcitationValue` DOUBLE UNSIGNED NULL ,
  `peakExcitationUnit` VARCHAR(20) NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `nominalLoadingName` VARCHAR(40) NULL ,
  `loadingCoefficient_DLCH` SMALLINT UNSIGNED NULL ,
  `additionalParameter` VARCHAR(100) NULL ,
  `notes` VARCHAR(300) NULL ,
  `SpecimenID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_ExperimentComputation`) ,
  INDEX `SpecimenIDindex` (`SpecimenID` ASC) ,
  INDEX `classIndex` (`class` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_MeshModel`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_MeshModel` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_MeshModel` (
  `idCache_MeshModel` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `meshModelName` VARCHAR(50) NULL ,
  `materialSymmetryType` VARCHAR(20) NULL ,
  `materialNonlinearity` VARCHAR(20) NULL ,
  `expCompID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_MeshModel`) ,
  INDEX `expCompIDindex` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_ComputerSystem`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_ComputerSystem` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_ComputerSystem` (
  `idCache_ComputerSystem` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `softwareName` VARCHAR(45) NULL ,
  `softwareVersion` VARCHAR(15) NULL ,
  `expCompID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_ComputerSystem`) ,
  INDEX `expCompIDindex` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_OriginalLoadingSignal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_OriginalLoadingSignal` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_OriginalLoadingSignal` (
  `idCache_OriginalLoadingSignal` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `originalLoadingName` VARCHAR(75) NULL ,
  `nature` VARCHAR(25) NULL ,
  `source` VARCHAR(60) NULL ,
  `peakExcitationValue` DOUBLE NULL ,
  `peakExcitationUnit` VARCHAR(20) NULL ,
  `direction` VARCHAR(100) NULL ,
  `idSignal` INT UNSIGNED NULL ,
  `signalLabel` VARCHAR(25) NULL ,
  `attribute` VARCHAR(30) NULL ,
  `physicalQuantity` VARCHAR(20) NULL ,
  `type` VARCHAR(15) NULL ,
  `unit` VARCHAR(10) NULL ,
  `location` VARCHAR(35) NULL ,
  `repetitionNumber` SMALLINT UNSIGNED NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `expCompID` INT UNSIGNED NULL ,
  `DLCH_axis` ENUM('horiz1','horiz2','vert') NOT NULL ,
  PRIMARY KEY (`idCache_OriginalLoadingSignal`) ,
  INDEX `expCompIDindex` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Signal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Signal` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Signal` (
  `idCache_Signal` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idSignal` INT UNSIGNED NULL ,
  `signalLabel` VARCHAR(25) NULL ,
  `attribute` VARCHAR(30) NULL ,
  `physicalQuantity` VARCHAR(20) NULL ,
  `type` VARCHAR(15) NULL ,
  `unit` VARCHAR(10) NULL ,
  `location` VARCHAR(35) NULL ,
  `repetitionNumber` SMALLINT UNSIGNED NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `expCompID` INT UNSIGNED NULL ,
  `signalType` ENUM('OUTPUT','INPUT_horiz1','INPUT_horiz2','INPUT_vert') NOT NULL ,
  PRIMARY KEY (`idCache_Signal`) ,
  INDEX `expCompIDindex` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Document`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Document` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Document` (
  `idCache_Document` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idDocument` INT UNSIGNED NULL ,
  `documentTitle` VARCHAR(150) NULL ,
  `documentAuthor` VARCHAR(300) NULL ,
  `documentDate` TIMESTAMP NULL ,
  `documentFormat` VARCHAR(7) NULL ,
  `documentSize` DOUBLE UNSIGNED NULL ,
  `abstract` TEXT NULL ,
  `scope` VARCHAR(150) NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `documentRole` VARCHAR(40) NULL ,
  `projectID` INT UNSIGNED NULL DEFAULT NULL ,
  `specimenID` INT UNSIGNED NULL DEFAULT NULL ,
  `expCompID` INT UNSIGNED NULL DEFAULT NULL ,
  `structuralComponentID` INT UNSIGNED NULL DEFAULT NULL ,
  `materialID` INT UNSIGNED NULL DEFAULT NULL ,
  `nominalPropertyID` INT UNSIGNED NULL DEFAULT NULL ,
  `actualMeanPropertyID` INT UNSIGNED NULL DEFAULT NULL ,
  `meshModelID` INT UNSIGNED NULL DEFAULT NULL ,
  `originalLoadingSignalID` INT UNSIGNED NULL DEFAULT NULL ,
  PRIMARY KEY (`idCache_Document`) ,
  INDEX `projectID` (`projectID` ASC) ,
  INDEX `specimenID` (`specimenID` ASC) ,
  INDEX `expCompID` (`expCompID` ASC) ,
  INDEX `structuralComponentID` (`structuralComponentID` ASC) ,
  INDEX `materialID` (`materialID` ASC) ,
  INDEX `nominalPropertyID` (`nominalPropertyID` ASC) ,
  INDEX `actualMeanPropertyID` (`actualMeanPropertyID` ASC) ,
  INDEX `meshModelID` (`meshModelID` ASC) ,
  INDEX `originalLoadingSignalID` (`originalLoadingSignalID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Image`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Image` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Image` (
  `idCache_Image` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idImage` INT UNSIGNED NULL ,
  `imageName` VARCHAR(50) NULL ,
  `imageDate` TIMESTAMP NULL ,
  `imageFormat` VARCHAR(7) NULL ,
  `imageAuthor` VARCHAR(100) NULL ,
  `imageSize` DOUBLE UNSIGNED NULL ,
  `summary` TINYTEXT NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `imageRole` VARCHAR(40) NULL ,
  `specimenID` INT UNSIGNED NULL ,
  `expCompID` INT UNSIGNED NULL ,
  `meshModelID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_Image`) ,
  INDEX `specimenID` (`specimenID` ASC) ,
  INDEX `expCompID` (`expCompID` ASC) ,
  INDEX `meshModelID` (`meshModelID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`Cache_Video`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`Cache_Video` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`Cache_Video` (
  `idCache_Video` INT UNSIGNED NOT NULL AUTO_INCREMENT ,
  `idVideo` INT UNSIGNED NULL ,
  `videoName` VARCHAR(50) NULL ,
  `videoDate` TIMESTAMP NULL ,
  `videoFormat` VARCHAR(7) NULL ,
  `videoSize` DOUBLE UNSIGNED NULL ,
  `summary` TINYTEXT NULL ,
  `privacy` ENUM('PARTNER','PUBLIC') NULL ,
  `videoRole` VARCHAR(40) NULL ,
  `expCompID` INT UNSIGNED NULL ,
  PRIMARY KEY (`idCache_Video`) ,
  INDEX `expCompID` (`expCompID` ASC) )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` (
  `ExperimentComputation_idExpComp` INT UNSIGNED NOT NULL ,
  `DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` INT UNSIGNED NOT NULL ,
  `loadingCoefficient` FLOAT NOT NULL ,
  PRIMARY KEY (`ExperimentComputation_idExpComp`, `DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic`, `loadingCoefficient`) ,
  INDEX `fk_ExperimentComputation_has_DetailedLoadingCharacteristic_Ex1` (`ExperimentComputation_idExpComp` ASC) ,
  INDEX `fk_ExperimentComputation_has_DetailedLoadingCharacteristic_De1` (`DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` ASC) ,
  CONSTRAINT `fk_ExperimentComputation_has_DetailedLoadingCharacteristic_Ex1`
    FOREIGN KEY (`ExperimentComputation_idExpComp` )
    REFERENCES `seriesdb`.`ExperimentComputation` (`idExpComp` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ExperimentComputation_has_DetailedLoadingCharacteristic_De1`
    FOREIGN KEY (`DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` )
    REFERENCES `seriesdb`.`DetailedLoadingCharacteristic` (`idDetailedLoadingCharacteristic` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` ;

CREATE  TABLE IF NOT EXISTS `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` (
  `DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` INT UNSIGNED NOT NULL ,
  `OriginalLoadingSignal_idOriginalLoadingSignal` INT UNSIGNED NOT NULL ,
  `loadingCoefficient` FLOAT NOT NULL ,
  `direction` ENUM('trans_horiz1','trans_horiz2','trans_vert','rot_horiz1','rot_horiz2','rot_vert') NOT NULL ,
  `EffectiveInputSignal` INT UNSIGNED NULL ,
  PRIMARY KEY (`DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic`, `OriginalLoadingSignal_idOriginalLoadingSignal`, `loadingCoefficient`, `direction`) ,
  INDEX `fk_DetailedLoadingCharacteristic_has_OriginalLoadingSignal_De1` (`DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` ASC) ,
  INDEX `fk_DetailedLoadingCharacteristic_has_OriginalLoadingSignal_Or1` (`OriginalLoadingSignal_idOriginalLoadingSignal` ASC) ,
  INDEX `fk_DetailedLoadingCharacteristic_OriginalLoadingSignal_Signal1` (`EffectiveInputSignal` ASC) ,
  CONSTRAINT `fk_DetailedLoadingCharacteristic_has_OriginalLoadingSignal_De1`
    FOREIGN KEY (`DetailedLoadingCharacteristic_idDetailedLoadingCharacteristic` )
    REFERENCES `seriesdb`.`DetailedLoadingCharacteristic` (`idDetailedLoadingCharacteristic` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DetailedLoadingCharacteristic_has_OriginalLoadingSignal_Or1`
    FOREIGN KEY (`OriginalLoadingSignal_idOriginalLoadingSignal` )
    REFERENCES `seriesdb`.`OriginalLoadingSignal` (`idOriginalLoadingSignal` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_DetailedLoadingCharacteristic_OriginalLoadingSignal_Signal1`
    FOREIGN KEY (`EffectiveInputSignal` )
    REFERENCES `seriesdb`.`Signals` (`idSignal` )
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`create_project` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER create_project BEFORE INSERT ON Project
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_project` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER update_project BEFORE UPDATE ON Project
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`create_document` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER create_document BEFORE INSERT ON Document
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_document` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER update_document BEFORE UPDATE ON Document
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_specimen` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER update_specimen BEFORE UPDATE ON Specimen
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`create_specimen` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER create_specimen BEFORE INSERT ON Specimen
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`create_expcom` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER create_expcom BEFORE INSERT ON ExperimentComputation
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_expcom` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER update_expcom BEFORE UPDATE ON ExperimentComputation
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_signal` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER update_signal BEFORE UPDATE ON Signals
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`create_signal` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER create_signal BEFORE INSERT ON Signals
FOR EACH ROW SET NEW.lastModification_time = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`originalloadingsignal_hasDocument_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasDocument. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER originalloadingsignal_hasDocument_insert AFTER INSERT ON OriginalLoadingSignal_Document
FOR EACH ROW BEGIN
  UPDATE OriginalLoadingSignal SET hasDocument = 'YES' WHERE idOriginalLoadingSignal = NEW.OriginalLoadingSignal_idOriginalLoadingSignal;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`originalloadingsignal_hasDocument_delete` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER originalloadingsignal_hasDocument_delete AFTER DELETE ON OriginalLoadingSignal_Document
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM OriginalLoadingSignal_Document WHERE OriginalLoadingSignal_idOriginalLoadingSignal = OLD.OriginalLoadingSignal_idOriginalLoadingSignal) = 0 ) THEN
  UPDATE OriginalLoadingSignal SET hasDocument = 'NO' WHERE idOriginalLoadingSignal = OLD.OriginalLoadingSignal_idOriginalLoadingSignal;
END IF;

END;
$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`meshmodel_hasDocument_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasDocument. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER meshmodel_hasDocument_insert AFTER INSERT ON MeshModel_Document
FOR EACH ROW BEGIN
  UPDATE MeshModel SET hasDocument = 'YES' WHERE idMeshModel = NEW.MeshModel_idMeshModel;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`meshmodel_hasDocument_delete` $$
USE `seriesdb`$$



CREATE DEFINER = 'userINT' TRIGGER meshmodel_hasDocument_delete AFTER DELETE ON MeshModel_Document
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM MeshModel_Document WHERE MeshModel_idMeshModel = OLD.MeshModel_idMeshModel) = 0 ) THEN
  UPDATE MeshModel SET hasDocument = 'NO' WHERE idMeshModel = OLD.MeshModel_idMeshModel;
END IF;

END;
$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`nominalproperty_hasDocument_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasDocument. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER nominalproperty_hasDocument_insert AFTER INSERT ON NominalProperty_Document
FOR EACH ROW BEGIN
  UPDATE NominalProperty SET hasDocument = 'YES' WHERE idNominalProperty = NEW.NominalProperty_idNominalProperty;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`nominalproperty_hasDocument_delete` $$
USE `seriesdb`$$



CREATE DEFINER = 'userINT' TRIGGER nominalproperty_hasDocument_delete AFTER DELETE ON NominalProperty_Document
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM NominalProperty_Document WHERE NominalProperty_idNominalProperty = OLD.NominalProperty_idNominalProperty) = 0 ) THEN
  UPDATE NominalProperty SET hasDocument = 'NO' WHERE idNominalProperty = OLD.NominalProperty_idNominalProperty;
END IF;

END;
$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`actualmeanproperty_hasDocument_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasDocument. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER actualmeanproperty_hasDocument_insert AFTER INSERT ON ActualMeanProperty_Document
FOR EACH ROW BEGIN
  UPDATE ActualMeanProperty SET hasDocument = 'YES' WHERE idActualMeanProperty = NEW.ActualMeanProperty_idActualMeanProperty;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`actualmeanproperty_hasDocument_delete` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER actualmeanproperty_hasDocument_delete AFTER DELETE ON ActualMeanProperty_Document
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM ActualMeanProperty_Document WHERE ActualMeanProperty_idActualMeanProperty = OLD.ActualMeanProperty_idActualMeanProperty) = 0 ) THEN
  UPDATE ActualMeanProperty SET hasDocument = 'NO' WHERE idActualMeanProperty = OLD.ActualMeanProperty_idActualMeanProperty;
END IF;

END;
$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`meshmodel_hasImage_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasImage. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER meshmodel_hasImage_insert AFTER INSERT ON MeshModel_Image
FOR EACH ROW BEGIN
  UPDATE MeshModel SET hasImage = 'YES' WHERE idMeshModel = NEW.MeshModel_idMeshModel;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`meshmodel_hasImage_delete` $$
USE `seriesdb`$$



CREATE DEFINER = 'userINT' TRIGGER meshmodel_hasImage_delete AFTER DELETE ON MeshModel_Image
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM MeshModel_Image WHERE MeshModel_idMeshModel = OLD.MeshModel_idMeshModel) = 0 ) THEN
  UPDATE MeshModel SET hasImage = 'NO' WHERE idMeshModel = OLD.MeshModel_idMeshModel;
END IF;

END;
$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`new_service` $$
USE `seriesdb`$$


CREATE DEFINER = 'userWS' TRIGGER new_service BEFORE INSERT ON ServiceRecord
FOR EACH ROW SET NEW.startOpTime = NOW();$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`update_service` $$
USE `seriesdb`$$


CREATE DEFINER = 'userWS' TRIGGER update_service BEFORE UPDATE ON ServiceRecord
FOR EACH ROW SET NEW.endOpTime = NOW();$$


DELIMITER ;

DELIMITER $$

USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`material_hasDocument_insert` $$
USE `seriesdb`$$



-- TRIGGERS for hasDocument. These triggers are optional, they just release
-- the interface from doing this work. UPDATE triggers are not considered (it
-- is assumed the ID will not be changed, rows are only created or deleted).

-- Note: This will update the table every time there is an INSERT!
CREATE DEFINER = 'userINT' TRIGGER material_hasDocument_insert AFTER INSERT ON Material_Document
FOR EACH ROW BEGIN
  UPDATE Material SET hasDocument = 'YES' WHERE idMaterial = NEW.Material_idMaterial;
END;
$$


USE `seriesdb`$$
DROP TRIGGER IF EXISTS `seriesdb`.`material_hasDocument_delete` $$
USE `seriesdb`$$


CREATE DEFINER = 'userINT' TRIGGER material_hasDocument_delete AFTER DELETE ON Material_Document
FOR EACH ROW BEGIN
IF ( (SELECT count(*) FROM Material_Document WHERE Material_idMaterial = OLD.Material_idMaterial) = 0 ) THEN
  UPDATE Material SET hasDocument = 'NO' WHERE idMaterial = OLD.Material_idMaterial;
END IF;

END;
$$


DELIMITER ;

grant SELECT on TABLE `seriesdb`.`ActualMeanProperty` to userWS;
grant SELECT on TABLE `seriesdb`.`ActualMeanProperty_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`ComputerSystem` to userWS;
grant SELECT on TABLE `seriesdb`.`DetailedLoadingCharacteristic` to userWS;
grant SELECT on TABLE `seriesdb`.`Device` to userWS;
grant SELECT on TABLE `seriesdb`.`Document` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Image` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Person` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Video` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputationType` to userWS;
grant SELECT on TABLE `seriesdb`.`Image` to userWS;
grant SELECT on TABLE `seriesdb`.`Infrastructure` to userWS;
grant SELECT on TABLE `seriesdb`.`Institution` to userWS;
grant SELECT on TABLE `seriesdb`.`Material` to userWS;
grant SELECT on TABLE `seriesdb`.`MeshModel` to userWS;
grant SELECT on TABLE `seriesdb`.`MeshModel_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`MeshModel_Image` to userWS;
grant SELECT on TABLE `seriesdb`.`MeshModel_Material` to userWS;
grant SELECT on TABLE `seriesdb`.`NominalProperty` to userWS;
grant SELECT on TABLE `seriesdb`.`NominalProperty_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`OriginalLoadingSignal` to userWS;
grant SELECT on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`Person` to userWS;
grant SELECT on TABLE `seriesdb`.`Project` to userWS;
grant SELECT on TABLE `seriesdb`.`Project_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`Project_Infrastructure` to userWS;
grant SELECT on TABLE `seriesdb`.`Project_Person` to userWS;
grant SELECT on TABLE `seriesdb`.`ProjectMainFocus` to userWS;
grant SELECT on TABLE `seriesdb`.`Scaling` to userWS;
grant SELECT on TABLE `seriesdb`.`Scaling_props` to userWS;
grant SELECT on TABLE `seriesdb`.`Sensor` to userWS;
grant SELECT on TABLE `seriesdb`.`Signals` to userWS;
grant SELECT on TABLE `seriesdb`.`Software` to userWS;
grant SELECT on TABLE `seriesdb`.`Specimen` to userWS;
grant SELECT on TABLE `seriesdb`.`Specimen_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`Specimen_Image` to userWS;
grant SELECT on TABLE `seriesdb`.`StructuralComponent` to userWS;
grant SELECT on TABLE `seriesdb`.`StructuralComponent_Material` to userWS;
grant SELECT on TABLE `seriesdb`.`Video` to userWS;
grant SELECT on TABLE `seriesdb`.`StructuralComponentType` to userWS;
grant SELECT on TABLE `seriesdb`.`SignalTimes` to userWS;
grant SELECT on TABLE `seriesdb`.`Partner` to userWS;
grant INSERT on TABLE `seriesdb`.`ServiceRecord` to userWS;
grant UPDATE on TABLE `seriesdb`.`ServiceRecord` to userWS;
grant TRIGGER on TABLE `seriesdb`.`ServiceRecord` to userWS;
grant SELECT on TABLE `seriesdb`.`ServiceRecord` to userWS;
grant SELECT on TABLE `seriesdb`.`Testing` to userWS;
grant SELECT on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userWS;
grant SELECT on TABLE `seriesdb`.`UpdateRecord` to userWS;
grant SELECT on TABLE `seriesdb`.`ProjectKeywords` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_File` to userWS;
grant SELECT on TABLE `seriesdb`.`DeviceType` to userWS;
grant SELECT on TABLE `seriesdb`.`SensorConfigurationSensor_Image` to userWS;
grant SELECT on TABLE `seriesdb`.`Project_ProjectKeywords` to userWS;
grant SELECT on TABLE `seriesdb`.`DeviceConfiguration` to userWS;
grant SELECT on TABLE `seriesdb`.`DeviceConfiguration_Device` to userWS;
grant SELECT on TABLE `seriesdb`.`DeviceRelation` to userWS;
grant SELECT on TABLE `seriesdb`.`StructuralComponent_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`Material_Document` to userWS;
grant INSERT on TABLE `seriesdb`.`DBinfo` to userWS;
grant SELECT on TABLE `seriesdb`.`DBinfo` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_ComputerSystem` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Document` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_ExperimentComputation` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Image` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Info` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Infrastructure` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Material` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_MeshModel` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_NominalProperty` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Person` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Project` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_ProjectKeywords` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Scaling` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Signal` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Specimen` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_StructuralComponent` to userWS;
grant SELECT on TABLE `seriesdb`.`Cache_Video` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_ComputerSystem` to userWS;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` to userWS;
grant SELECT on TABLE `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` to userWS;
grant INSERT on TABLE `seriesdb`.`ProjectMainFocus` to userINT;
grant DELETE on TABLE `seriesdb`.`ProjectMainFocus` to userINT;
grant SELECT on TABLE `seriesdb`.`ProjectMainFocus` to userINT;
grant UPDATE on TABLE `seriesdb`.`ProjectMainFocus` to userINT;
grant TRIGGER on TABLE `seriesdb`.`ProjectMainFocus` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_Image` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Image` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_Image` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_Image` to userINT;
grant DELETE on TABLE `seriesdb`.`ActualMeanProperty` to userINT;
grant INSERT on TABLE `seriesdb`.`ActualMeanProperty` to userINT;
grant SELECT on TABLE `seriesdb`.`ActualMeanProperty` to userINT;
grant UPDATE on TABLE `seriesdb`.`ActualMeanProperty` to userINT;
grant DELETE on TABLE `seriesdb`.`ActualMeanProperty_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`ActualMeanProperty_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`ActualMeanProperty_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`ActualMeanProperty_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`ActualMeanProperty_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`ComputerSystem` to userINT;
grant INSERT on TABLE `seriesdb`.`ComputerSystem` to userINT;
grant SELECT on TABLE `seriesdb`.`ComputerSystem` to userINT;
grant UPDATE on TABLE `seriesdb`.`ComputerSystem` to userINT;
grant DELETE on TABLE `seriesdb`.`DetailedLoadingCharacteristic` to userINT;
grant INSERT on TABLE `seriesdb`.`DetailedLoadingCharacteristic` to userINT;
grant SELECT on TABLE `seriesdb`.`DetailedLoadingCharacteristic` to userINT;
grant UPDATE on TABLE `seriesdb`.`DetailedLoadingCharacteristic` to userINT;
grant DELETE on TABLE `seriesdb`.`Device` to userINT;
grant INSERT on TABLE `seriesdb`.`Device` to userINT;
grant SELECT on TABLE `seriesdb`.`Device` to userINT;
grant UPDATE on TABLE `seriesdb`.`Device` to userINT;
grant DELETE on TABLE `seriesdb`.`Document` to userINT;
grant INSERT on TABLE `seriesdb`.`Document` to userINT;
grant SELECT on TABLE `seriesdb`.`Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Document` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation` to userINT;
grant TRIGGER on TABLE `seriesdb`.`ExperimentComputation` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_Person` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_Person` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Person` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_Person` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_Video` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_Video` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_Video` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_Video` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputationType` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputationType` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputationType` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputationType` to userINT;
grant DELETE on TABLE `seriesdb`.`Image` to userINT;
grant INSERT on TABLE `seriesdb`.`Image` to userINT;
grant SELECT on TABLE `seriesdb`.`Image` to userINT;
grant UPDATE on TABLE `seriesdb`.`Image` to userINT;
grant DELETE on TABLE `seriesdb`.`Infrastructure` to userINT;
grant INSERT on TABLE `seriesdb`.`Infrastructure` to userINT;
grant SELECT on TABLE `seriesdb`.`Infrastructure` to userINT;
grant UPDATE on TABLE `seriesdb`.`Infrastructure` to userINT;
grant DELETE on TABLE `seriesdb`.`Institution` to userINT;
grant INSERT on TABLE `seriesdb`.`Institution` to userINT;
grant SELECT on TABLE `seriesdb`.`Institution` to userINT;
grant UPDATE on TABLE `seriesdb`.`Institution` to userINT;
grant DELETE on TABLE `seriesdb`.`Material` to userINT;
grant INSERT on TABLE `seriesdb`.`Material` to userINT;
grant SELECT on TABLE `seriesdb`.`Material` to userINT;
grant UPDATE on TABLE `seriesdb`.`Material` to userINT;
grant DELETE on TABLE `seriesdb`.`MeshModel` to userINT;
grant INSERT on TABLE `seriesdb`.`MeshModel` to userINT;
grant SELECT on TABLE `seriesdb`.`MeshModel` to userINT;
grant UPDATE on TABLE `seriesdb`.`MeshModel` to userINT;
grant DELETE on TABLE `seriesdb`.`MeshModel_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`MeshModel_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`MeshModel_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`MeshModel_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`MeshModel_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`MeshModel_Image` to userINT;
grant INSERT on TABLE `seriesdb`.`MeshModel_Image` to userINT;
grant SELECT on TABLE `seriesdb`.`MeshModel_Image` to userINT;
grant UPDATE on TABLE `seriesdb`.`MeshModel_Image` to userINT;
grant TRIGGER on TABLE `seriesdb`.`MeshModel_Image` to userINT;
grant DELETE on TABLE `seriesdb`.`MeshModel_Material` to userINT;
grant INSERT on TABLE `seriesdb`.`MeshModel_Material` to userINT;
grant SELECT on TABLE `seriesdb`.`MeshModel_Material` to userINT;
grant UPDATE on TABLE `seriesdb`.`MeshModel_Material` to userINT;
grant DELETE on TABLE `seriesdb`.`NominalProperty` to userINT;
grant INSERT on TABLE `seriesdb`.`NominalProperty` to userINT;
grant SELECT on TABLE `seriesdb`.`NominalProperty` to userINT;
grant UPDATE on TABLE `seriesdb`.`NominalProperty` to userINT;
grant DELETE on TABLE `seriesdb`.`NominalProperty_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`NominalProperty_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`NominalProperty_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`NominalProperty_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`NominalProperty_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`OriginalLoadingSignal` to userINT;
grant INSERT on TABLE `seriesdb`.`OriginalLoadingSignal` to userINT;
grant SELECT on TABLE `seriesdb`.`OriginalLoadingSignal` to userINT;
grant UPDATE on TABLE `seriesdb`.`OriginalLoadingSignal` to userINT;
grant DELETE on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`OriginalLoadingSignal_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`Person` to userINT;
grant INSERT on TABLE `seriesdb`.`Person` to userINT;
grant SELECT on TABLE `seriesdb`.`Person` to userINT;
grant UPDATE on TABLE `seriesdb`.`Person` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Person` to userINT;
grant DELETE on TABLE `seriesdb`.`Project` to userINT;
grant INSERT on TABLE `seriesdb`.`Project` to userINT;
grant SELECT on TABLE `seriesdb`.`Project` to userINT;
grant UPDATE on TABLE `seriesdb`.`Project` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Project` to userINT;
grant DELETE on TABLE `seriesdb`.`Project_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`Project_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`Project_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`Project_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Project_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`Project_Infrastructure` to userINT;
grant INSERT on TABLE `seriesdb`.`Project_Infrastructure` to userINT;
grant SELECT on TABLE `seriesdb`.`Project_Infrastructure` to userINT;
grant UPDATE on TABLE `seriesdb`.`Project_Infrastructure` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Project_Infrastructure` to userINT;
grant DELETE on TABLE `seriesdb`.`Project_Person` to userINT;
grant INSERT on TABLE `seriesdb`.`Project_Person` to userINT;
grant SELECT on TABLE `seriesdb`.`Project_Person` to userINT;
grant UPDATE on TABLE `seriesdb`.`Project_Person` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Project_Person` to userINT;
grant DELETE on TABLE `seriesdb`.`Scaling` to userINT;
grant INSERT on TABLE `seriesdb`.`Scaling` to userINT;
grant SELECT on TABLE `seriesdb`.`Scaling` to userINT;
grant UPDATE on TABLE `seriesdb`.`Scaling` to userINT;
grant DELETE on TABLE `seriesdb`.`Scaling_props` to userINT;
grant INSERT on TABLE `seriesdb`.`Scaling_props` to userINT;
grant SELECT on TABLE `seriesdb`.`Scaling_props` to userINT;
grant UPDATE on TABLE `seriesdb`.`Scaling_props` to userINT;
grant DELETE on TABLE `seriesdb`.`Sensor` to userINT;
grant INSERT on TABLE `seriesdb`.`Sensor` to userINT;
grant SELECT on TABLE `seriesdb`.`Sensor` to userINT;
grant UPDATE on TABLE `seriesdb`.`Sensor` to userINT;
grant DELETE on TABLE `seriesdb`.`Signals` to userINT;
grant INSERT on TABLE `seriesdb`.`Signals` to userINT;
grant SELECT on TABLE `seriesdb`.`Signals` to userINT;
grant UPDATE on TABLE `seriesdb`.`Signals` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Signals` to userINT;
grant DELETE on TABLE `seriesdb`.`Software` to userINT;
grant INSERT on TABLE `seriesdb`.`Software` to userINT;
grant SELECT on TABLE `seriesdb`.`Software` to userINT;
grant UPDATE on TABLE `seriesdb`.`Software` to userINT;
grant DELETE on TABLE `seriesdb`.`Specimen` to userINT;
grant INSERT on TABLE `seriesdb`.`Specimen` to userINT;
grant SELECT on TABLE `seriesdb`.`Specimen` to userINT;
grant UPDATE on TABLE `seriesdb`.`Specimen` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Specimen` to userINT;
grant DELETE on TABLE `seriesdb`.`Specimen_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`Specimen_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`Specimen_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`Specimen_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`Specimen_Image` to userINT;
grant INSERT on TABLE `seriesdb`.`Specimen_Image` to userINT;
grant SELECT on TABLE `seriesdb`.`Specimen_Image` to userINT;
grant UPDATE on TABLE `seriesdb`.`Specimen_Image` to userINT;
grant DELETE on TABLE `seriesdb`.`StructuralComponent` to userINT;
grant INSERT on TABLE `seriesdb`.`StructuralComponent` to userINT;
grant SELECT on TABLE `seriesdb`.`StructuralComponent` to userINT;
grant UPDATE on TABLE `seriesdb`.`StructuralComponent` to userINT;
grant DELETE on TABLE `seriesdb`.`StructuralComponent_Material` to userINT;
grant INSERT on TABLE `seriesdb`.`StructuralComponent_Material` to userINT;
grant SELECT on TABLE `seriesdb`.`StructuralComponent_Material` to userINT;
grant UPDATE on TABLE `seriesdb`.`StructuralComponent_Material` to userINT;
grant DELETE on TABLE `seriesdb`.`Video` to userINT;
grant INSERT on TABLE `seriesdb`.`Video` to userINT;
grant SELECT on TABLE `seriesdb`.`Video` to userINT;
grant UPDATE on TABLE `seriesdb`.`Video` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Video` to userINT;
grant DELETE on TABLE `seriesdb`.`StructuralComponentType` to userINT;
grant INSERT on TABLE `seriesdb`.`StructuralComponentType` to userINT;
grant SELECT on TABLE `seriesdb`.`StructuralComponentType` to userINT;
grant UPDATE on TABLE `seriesdb`.`StructuralComponentType` to userINT;
grant TRIGGER on TABLE `seriesdb`.`StructuralComponentType` to userINT;
grant DELETE on TABLE `seriesdb`.`SignalTimes` to userINT;
grant SELECT on TABLE `seriesdb`.`SignalTimes` to userINT;
grant INSERT on TABLE `seriesdb`.`SignalTimes` to userINT;
grant UPDATE on TABLE `seriesdb`.`SignalTimes` to userINT;
grant TRIGGER on TABLE `seriesdb`.`SignalTimes` to userINT;
grant DELETE on TABLE `seriesdb`.`Partner` to userINT;
grant INSERT on TABLE `seriesdb`.`Partner` to userINT;
grant SELECT on TABLE `seriesdb`.`Partner` to userINT;
grant UPDATE on TABLE `seriesdb`.`Partner` to userINT;
grant SELECT on TABLE `seriesdb`.`ServiceRecord` to userINT;
grant DELETE on TABLE `seriesdb`.`ServiceRecord` to userINT;
grant SELECT on TABLE `seriesdb`.`Testing` to userINT;
grant UPDATE on TABLE `seriesdb`.`Testing` to userINT;
grant INSERT on TABLE `seriesdb`.`Testing` to userINT;
grant DELETE on TABLE `seriesdb`.`Testing` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Testing` to userINT;
grant DELETE on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userINT;
grant INSERT on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userINT;
grant SELECT on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userINT;
grant UPDATE on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userINT;
grant TRIGGER on TABLE `seriesdb`.`SensorConfiguration_Sensor` to userINT;
grant SELECT on TABLE `seriesdb`.`UpdateRecord` to userINT;
grant UPDATE on TABLE `seriesdb`.`UpdateRecord` to userINT;
grant DELETE on TABLE `seriesdb`.`UpdateRecord` to userINT;
grant INSERT on TABLE `seriesdb`.`UpdateRecord` to userINT;
grant DELETE on TABLE `seriesdb`.`ProjectKeywords` to userINT;
grant SELECT on TABLE `seriesdb`.`ProjectKeywords` to userINT;
grant INSERT on TABLE `seriesdb`.`ProjectKeywords` to userINT;
grant UPDATE on TABLE `seriesdb`.`ProjectKeywords` to userINT;
grant DELETE on TABLE `seriesdb`.`DeviceType` to userINT;
grant INSERT on TABLE `seriesdb`.`DeviceType` to userINT;
grant SELECT on TABLE `seriesdb`.`DeviceType` to userINT;
grant UPDATE on TABLE `seriesdb`.`DeviceType` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_File` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_File` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_File` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_File` to userINT;
grant DELETE on TABLE `seriesdb`.`File` to userINT;
grant SELECT on TABLE `seriesdb`.`File` to userINT;
grant UPDATE on TABLE `seriesdb`.`File` to userINT;
grant INSERT on TABLE `seriesdb`.`File` to userINT;
grant DELETE on TABLE `seriesdb`.`SensorConfigurationSensor_Image` to userINT;
grant INSERT on TABLE `seriesdb`.`SensorConfigurationSensor_Image` to userINT;
grant SELECT on TABLE `seriesdb`.`SensorConfigurationSensor_Image` to userINT;
grant UPDATE on TABLE `seriesdb`.`SensorConfigurationSensor_Image` to userINT;
grant DELETE on TABLE `seriesdb`.`Project_ProjectKeywords` to userINT;
grant SELECT on TABLE `seriesdb`.`Project_ProjectKeywords` to userINT;
grant UPDATE on TABLE `seriesdb`.`Project_ProjectKeywords` to userINT;
grant INSERT on TABLE `seriesdb`.`Project_ProjectKeywords` to userINT;
grant DELETE on TABLE `seriesdb`.`DeviceConfiguration` to userINT;
grant SELECT on TABLE `seriesdb`.`DeviceConfiguration` to userINT;
grant UPDATE on TABLE `seriesdb`.`DeviceConfiguration` to userINT;
grant INSERT on TABLE `seriesdb`.`DeviceConfiguration` to userINT;
grant DELETE on TABLE `seriesdb`.`DeviceConfiguration_Device` to userINT;
grant SELECT on TABLE `seriesdb`.`DeviceConfiguration_Device` to userINT;
grant UPDATE on TABLE `seriesdb`.`DeviceConfiguration_Device` to userINT;
grant INSERT on TABLE `seriesdb`.`DeviceConfiguration_Device` to userINT;
grant DELETE on TABLE `seriesdb`.`DeviceRelation` to userINT;
grant SELECT on TABLE `seriesdb`.`DeviceRelation` to userINT;
grant UPDATE on TABLE `seriesdb`.`DeviceRelation` to userINT;
grant INSERT on TABLE `seriesdb`.`DeviceRelation` to userINT;
grant DELETE on TABLE `seriesdb`.`StructuralComponent_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`StructuralComponent_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`StructuralComponent_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`StructuralComponent_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`Material_Document` to userINT;
grant INSERT on TABLE `seriesdb`.`Material_Document` to userINT;
grant SELECT on TABLE `seriesdb`.`Material_Document` to userINT;
grant UPDATE on TABLE `seriesdb`.`Material_Document` to userINT;
grant TRIGGER on TABLE `seriesdb`.`Material_Document` to userINT;
grant DELETE on TABLE `seriesdb`.`DBinfo` to userINT;
grant INSERT on TABLE `seriesdb`.`DBinfo` to userINT;
grant SELECT on TABLE `seriesdb`.`DBinfo` to userINT;
grant UPDATE on TABLE `seriesdb`.`DBinfo` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_ComputerSystem` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_ComputerSystem` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_ComputerSystem` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_ComputerSystem` to userINT;
grant DELETE on TABLE `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` to userINT;
grant INSERT on TABLE `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` to userINT;
grant SELECT on TABLE `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` to userINT;
grant UPDATE on TABLE `seriesdb`.`ExperimentComputation_DetailedLoadingCharacteristic` to userINT;
grant DELETE on TABLE `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` to userINT;
grant INSERT on TABLE `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` to userINT;
grant SELECT on TABLE `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` to userINT;
grant UPDATE on TABLE `seriesdb`.`DetailedLoadingCharacteristic_OriginalLoadingSignal` to userINT;
grant DELETE on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_ActualMeanProperty` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_ComputerSystem` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_ComputerSystem` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_ComputerSystem` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_ComputerSystem` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_ComputerSystem` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Document` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Document` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Document` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Document` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Document` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_ExperimentComputation` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_ExperimentComputation` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_ExperimentComputation` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_ExperimentComputation` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Image` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Image` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Image` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Image` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Image` to userCache;
grant TRIGGER on TABLE `seriesdb`.`Cache_Info` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Info` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Info` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Info` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Info` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Infrastructure` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Infrastructure` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Infrastructure` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Infrastructure` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Material` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Material` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Material` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Material` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Material` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_MeshModel` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_MeshModel` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_MeshModel` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_MeshModel` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_MeshModel` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_NominalProperty` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_NominalProperty` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_NominalProperty` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_NominalProperty` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_NominalProperty` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_OriginalLoadingSignal` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Person` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Person` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Person` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Person` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Person` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Project` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Project` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Project` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Project` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Project` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_ProjectKeywords` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_ProjectKeywords` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_ProjectKeywords` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_ProjectKeywords` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_ProjectKeywords` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Scaling` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Scaling` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Scaling` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Scaling` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Scaling` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Signal` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Signal` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Signal` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Signal` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Signal` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Specimen` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Specimen` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Specimen` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Specimen` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Specimen` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_StructuralComponent` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_StructuralComponent` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_StructuralComponent` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_StructuralComponent` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_StructuralComponent` to userCache;
grant DELETE on TABLE `seriesdb`.`Cache_Video` to userCache;
grant INSERT on TABLE `seriesdb`.`Cache_Video` to userCache;
grant SELECT on TABLE `seriesdb`.`Cache_Video` to userCache;
grant UPDATE on TABLE `seriesdb`.`Cache_Video` to userCache;
grant DROP on TABLE `seriesdb`.`Cache_Video` to userCache;
grant INSERT on TABLE `seriesdb`.`ServiceRecord` to userCache;
grant UPDATE on TABLE `seriesdb`.`ServiceRecord` to userCache;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`ProjectMainFocus`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Structural performance');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Structural Performance-Deficient Structures');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Retrofit techniques');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Code checking');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Experimental technique');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Model calibration');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Foundation performance');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Foundation retrofit');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Earthwork performance');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Earthwork retrofit');
INSERT INTO `seriesdb`.`ProjectMainFocus` (`idProjectMainFocus`, `projectMainFocus`) VALUES (0, 'Buried structures and pipes');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`Institution`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (1, 'University of Oxford', 'UOXF', '00441865270000', 'Oxford, United Kingdom', 'http://www.ox.ac.uk/');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'University of Bristol', 'UBRIS', '00441173315709', 'Bristol, United Kingdom', 'http://www.bris.ac.uk/');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'University of Cambridge', 'UCAM', NULL, 'Cambridge, United Kingdom', 'http://www.cam.ac.uk/');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Joint Research Center', 'JRC', NULL, 'Ispra, Italy', 'http://elsa.jrc.ec.europa.eu/');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'University of Patras', 'UPAT', '00302610991822', 'Patras, Greece', 'http://www.upatras.gr/index/index/lang/en');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Aristotelio Panepistimio Thessalonikis', 'AUTH', NULL, 'Thessaloniki, Greece', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Commissariat Énergie Atomique', 'CEA', NULL, 'Paris, France', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Centro Europeo di Formazione e Ricerca in Ingegneria Sismica', 'EUCENTRE', NULL, 'Pavia, Italy', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Géodynamique et Structure', 'GDS', NULL, '', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Institute of Earthquake Engineering and Engineering Seismology', 'IZIIS', NULL, 'Skopje, Macedonia', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Laboratoire Central des Ponts et Chaussées', 'LCPC', NULL, 'Nantes, France', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Laboratório Nacional de Engenharia Civil ', 'LNEC', NULL, 'Lisboa, Portugal', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Middle East Technical University ', 'METU', NULL, 'Ankara, Turkey', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Technical University Gheorghe Asachi of Iasi', 'TUIASI', NULL, 'Iasi, Romania', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Universitá degli Studi di Trento', 'UNITN', NULL, 'Trento, Italy', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Universität Kassel', 'UNIKA', NULL, 'Kassel, Germany', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Universita degli Studi di Napoli Federico II', 'UNAP', NULL, 'Napoli, Italy', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Technical University of Istanbul ', 'ITU', NULL, 'Istanbul, Turkey', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'National Technical University of Athens', 'NTUA', NULL, 'Athens, Greece', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Bogazici University', 'KOERI', NULL, 'Bogazici, Turkey', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Univerza V Ljubljani', 'UL', NULL, 'Ljubjana, Slovenia', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'P&P LMC Srl', 'PeP', NULL, 'Bergamo, Italy', NULL);
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'VCE Holding GmbH', 'VCE', '004318975339', 'Wien, Austria', 'http://www.vce.at/');
INSERT INTO `seriesdb`.`Institution` (`idInstitution`, `institutionName`, `institutionAcronym`, `institutionContact`, `location`, `institutionWebsite`) VALUES (NULL, 'Other', 'Other', 'N/A', 'N/A', 'N/A');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`Person`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`Person` (`idPerson`, `foreName`, `familyName`, `contactEmail`, `contactPhone`, `userImage`, `institutionID`, `idUser`, `userID`) VALUES (NULL, 'Ignacio', 'Lamata Martinez', 'ignacio.lamata@eng.ox.ac.uk', NULL, NULL, 1, NULL, NULL);
INSERT INTO `seriesdb`.`Person` (`idPerson`, `foreName`, `familyName`, `contactEmail`, `contactPhone`, `userImage`, `institutionID`, `idUser`, `userID`) VALUES (NULL, 'Martin', 'Williams', 'martin.williams@eng.ox.ac.uk', NULL, NULL, 1, NULL, NULL);
INSERT INTO `seriesdb`.`Person` (`idPerson`, `foreName`, `familyName`, `contactEmail`, `contactPhone`, `userImage`, `institutionID`, `idUser`, `userID`) VALUES (NULL, 'Tony', 'Blackeborough', 'tony.blackeborough@eng.ox.ac.uk', NULL, NULL, 1, NULL, NULL);

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`Infrastructure`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`Infrastructure` (`idInfrastructure`, `infrastructureName`, `facilityName`, `location`, `InfrastructureImage`) VALUES (0, 'Structural Dynamics Laboratory', 'Reaction wall', 'Oxford, UK', NULL);
INSERT INTO `seriesdb`.`Infrastructure` (`idInfrastructure`, `infrastructureName`, `facilityName`, `location`, `InfrastructureImage`) VALUES (0, 'Structural Dynamics Laboratory', 'Cable facility', 'Oxford, UK', NULL);
INSERT INTO `seriesdb`.`Infrastructure` (`idInfrastructure`, `infrastructureName`, `facilityName`, `location`, `InfrastructureImage`) VALUES (0, 'Structural Dynamics Laboratory', 'Computer', 'Oxford, UK', NULL);

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`StructuralComponentType`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, '2D frame');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, '3D frame');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, '2D  structure');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, '3D  structure');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'bridge');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'piles & pile groups');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'retaining walls');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'foundations');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'earth structures -dams');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'reinforced soil');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'rock formations');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'tunnels');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'piping');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'air conditioning units');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'computer systems');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'medical equipment');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'power generation & transmission components');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'wind turbines ');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'connection:expansion joints');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'connection: seismic joint');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'isolation devices: sliders');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'isolation devices: elastomeric bearings');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'isolation devices: lead-rubber bearings');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'isolation devices: friction pendulum bearings');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'passive structural control devices: hydraulic dampers');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'passive structural control devices:  electrical dampers');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'passive structural control devices: MR dampers');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'passive structural control devices: friction dampers');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'passive structural control devices: tuned mass dampers');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'active structural control devices');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'beam');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'column');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'girder');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'tendon');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'cable');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'trusse');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'brace');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'pier');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'slab');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'deck');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'pavement');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'shear wall');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'load bearing wall');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'non-structural partition');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'shell');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'membrane');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'arch');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'cladding');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (0, 'vault');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (NULL, 'soil');
INSERT INTO `seriesdb`.`StructuralComponentType` (`idStructuralComponentType`, `typeName`) VALUES (NULL, 'shallow foundation');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`Material`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'R/C', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'steel', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'masonry', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'frp', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'precast', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'glass', 'NO');
INSERT INTO `seriesdb`.`Material` (`idMaterial`, `materialName`, `hasDocument`) VALUES (NULL, 'timber ', 'NO');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`ExperimentComputationType`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'quasi-static with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'quasi-static without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'PsD with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'PsD without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'shaking table with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'shaking table without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'centrifuge with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'centrifuge without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'distributed with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'distributed without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'bearing tester with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'bearing tester without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'damper tester with substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'damper tester without substructuring', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'hammer in-situ', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'hammer in lab', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'shaker in-situ', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'shaker in lab', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'monitoring in-situ', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'monitoring in lab', 'EXPERIMENT');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Linear time-history', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Non-linear time-history', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Single-mode push-over', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Multi-mode push-over', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Non-linear static', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Equivalent static', 'COMPUTATION');
INSERT INTO `seriesdb`.`ExperimentComputationType` (`idExperimentComputationType`, `typeName`, `type`) VALUES (0, 'Modal analysis', 'COMPUTATION');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`DeviceType`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Actuator');
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Servovalve');
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Slave');
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Controller');
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Shaker');
INSERT INTO `seriesdb`.`DeviceType` (`idDeviceType`, `deviceTypeName`) VALUES (NULL, 'Hammer');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`Testing`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`Testing` (`idTesting`, `text`) VALUES (0, 'Welcome to SERIES');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`ProjectKeywords`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Experiment');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Computation');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'In situ/In lab');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'With/Without substructuring');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Distributed');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Static');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Monotonic');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Push-Over');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Cyclic Test');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Psd');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Shaking Table');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Sinusoidal Vibration');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Centrifuge');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Sines Sweep');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Multi Frequency Dynamic');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Impulsive Test ');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Stepped Sined Tests');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Low-Cycle Fatigue');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'White Noise');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Vibration');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Bearing Tester');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Damper Tester');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Tri-Axial Multi-Frequency Tests');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Environmental Vibration Tests');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Free Vibration Tests');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Forced Vibration Tests');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Hammer');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Shaker');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Monitoring');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Linear Time-History');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Non-Linear Time-History');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Single-Mode Push-Over');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Multi-Mode Push-Over');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Non-Linear Static');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Equivalent Static');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Modal Analysis');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Free field');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Soil Structure interaction');
INSERT INTO `seriesdb`.`ProjectKeywords` (`idProjectKeywords`, `keywordName`) VALUES (NULL, 'Shallow foundations');

COMMIT;

-- -----------------------------------------------------
-- Data for table `seriesdb`.`DBinfo`
-- -----------------------------------------------------
SET AUTOCOMMIT=0;
INSERT INTO `seriesdb`.`DBinfo` (`idDBinfo`, `databaseVersion`, `databaseDate`, `databaseUpdate`, `notes`, `cacheVersion`) VALUES (NULL, 'OXFORD SERIES DATABASE (ILM) v0.99n', '2011-07-12 08:00:00', NULL, 'Pre release version', 'OXFORD_CACHE 0.1');

COMMIT;
